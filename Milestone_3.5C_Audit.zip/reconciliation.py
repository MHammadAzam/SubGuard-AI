"""Deterministic Cross-Document Reconciliation Logic.

Architectural Invariant:
'AI extracts information. Deterministic Python rules evaluate it. Humans resolve uncertainty.'

This module implements the deterministic reconciliation stage between document extraction
and compliance evaluation:
1. Entity identity reconciliation (independent of document roles)
2. Contractual role compatibility and contractual-role satisfaction
3. Policy identifier reconciliation (strict 5-tier classification)
4. Temporal date reconciliation with nullable active states
5. Multi-edge document relationship graph classification with relationship-specific evidence
6. Cross-document evidence and referential integrity validation
7. Deterministic summary derivation
"""
from __future__ import annotations

import re
from datetime import date
from typing import Dict, List, Optional, Set, Tuple

from app.compliance.evaluator import _clean_entity_name, _split_core_and_suffix, compare_entity_names
from app.schemas.insurance import (
    CoverageType,
    DocumentType,
    EvidenceReference,
    Severity,
)
from app.schemas.reconciliation import (
    CrossDocumentReconciliationResult,
    DateReconciliationRecord,
    DiscrepancyCategory,
    DocumentDiscrepancy,
    DocumentManifestEntry,
    DocumentRelationshipEdge,
    DocumentRelationshipType,
    EdgeClassification,
    EntityMatchClassification,
    EntityReconciliationRecord,
    EntityRole,
    MissingEvidenceProvenance,
    PolicyMatchClassification,
    PolicyReconciliationRecord,
    is_role_compatible,
    normalize_policy_identifier,
    validate_evidence_reference,
)


# =============================================================================
# 1. Policy Number Reconciliation
# =============================================================================

def _is_possible_policy_family(norm_a: str, norm_b: str) -> bool:
    """Detect if two normalized policy identifiers share a common family base
    but differ in renewal, term, sequence suffix, or leading zeros.
    
    A possible renewal-family or leading-zero match must NEVER be treated as exact
    or formatting-normalized equality.
    """
    if not norm_a or not norm_b:
        return False

    # 1. Leading zero difference (e.g. '0012345' vs '12345')
    a_lstrip = norm_a.lstrip("0")
    b_lstrip = norm_b.lstrip("0")
    if a_lstrip and b_lstrip and a_lstrip == b_lstrip and norm_a != norm_b:
        return True

    # 2. Prefix relationship with short trailing suffix (1-4 chars)
    if norm_a.startswith(norm_b) and 1 <= len(norm_a) - len(norm_b) <= 4:
        return True
    if norm_b.startswith(norm_a) and 1 <= len(norm_b) - len(norm_a) <= 4:
        return True

    # 3. Substantial common base with short trailing difference (1-4 chars each)
    common_len = 0
    for ca, cb in zip(norm_a, norm_b):
        if ca == cb:
            common_len += 1
        else:
            break
    if common_len >= 4 and (len(norm_a) - common_len <= 4) and (len(norm_b) - common_len <= 4):
        return True

    return False


def reconcile_policy_identifiers(
    coi_document_id: str,
    coi_policy_number: Optional[str],
    coi_evidence: Optional[EvidenceReference],
    endorsement_document_id: str,
    endorsement_policy_number: Optional[str],
    endorsement_evidence: Optional[EvidenceReference],
    evidence_chain: Optional[Tuple[EvidenceReference, ...]] = None,
) -> PolicyReconciliationRecord:
    r"""Deterministically reconcile policy numbers between a COI and an Endorsement.
    
    Enforces the strict 5-tier classification:
    - EXACT: character-for-character identical strings
    - FORMATTING_NORMALIZED: identical after permitted delimiter stripping, differing raw
    - POSSIBLE_FAMILY: common base with differing renewal/term suffix or leading zeros (requires review)
    - AMBIGUOUS: missing or unparseable policy numbers (requires review)
    - CONFLICTING: distinct, incompatible policy numbers (requires review)
    
    Normalization Rules:
    - Strips permitted delimiter characters: whitespace, hyphens, slashes, periods: [\\s\\-\\/\.]
    - Converts to uppercase.
    - Preserves all alphanumeric characters, leading zeros, sequence numbers,
      and renewal/term suffixes.
    - Does NOT remove leading zeros (e.g. '0012345' is NOT converted to '12345').
    - Does NOT remove renewal suffixes (e.g. '-01', '-02' are preserved).
    """
    coi_raw = (coi_policy_number or "").strip()
    end_raw = (endorsement_policy_number or "").strip()

    # Determine default evidence chain if omitted
    if evidence_chain is None:
        chain_refs: List[EvidenceReference] = []
        if coi_evidence is not None:
            chain_refs.append(coi_evidence)
        if endorsement_evidence is not None:
            chain_refs.append(endorsement_evidence)
        evidence_chain = tuple(chain_refs)

    # 1. Missing or unparseable policy numbers
    if not coi_raw or not end_raw:
        return PolicyReconciliationRecord(
            coi_document_id=coi_document_id,
            coi_policy_number=coi_policy_number,
            coi_evidence=coi_evidence,
            endorsement_document_id=endorsement_document_id,
            endorsement_policy_number=endorsement_policy_number,
            endorsement_evidence=endorsement_evidence,
            classification=PolicyMatchClassification.AMBIGUOUS,
            evidence_chain=evidence_chain,
            is_confirmed_match=False,
            requires_human_review=True,
            review_reason_code="MISSING_OR_UNPARSEABLE_POLICY_NUMBER",
        )

    # 2. EXACT character-for-character match
    if coi_raw == end_raw:
        has_citations = (coi_evidence is not None and endorsement_evidence is not None)
        if has_citations:
            return PolicyReconciliationRecord(
                coi_document_id=coi_document_id,
                coi_policy_number=coi_policy_number,
                coi_evidence=coi_evidence,
                endorsement_document_id=endorsement_document_id,
                endorsement_policy_number=endorsement_policy_number,
                endorsement_evidence=endorsement_evidence,
                classification=PolicyMatchClassification.EXACT,
                evidence_chain=evidence_chain,
                is_confirmed_match=True,
                requires_human_review=False,
                review_reason_code=None,
            )
        else:
            return PolicyReconciliationRecord(
                coi_document_id=coi_document_id,
                coi_policy_number=coi_policy_number,
                coi_evidence=coi_evidence,
                endorsement_document_id=endorsement_document_id,
                endorsement_policy_number=endorsement_policy_number,
                endorsement_evidence=endorsement_evidence,
                classification=PolicyMatchClassification.AMBIGUOUS,
                evidence_chain=evidence_chain,
                is_confirmed_match=False,
                requires_human_review=True,
                review_reason_code="POLICY_NUMBER_MISSING_EVIDENCE",
            )

    # 3. Delimiter-normalized match
    norm_coi = normalize_policy_identifier(coi_raw)
    norm_end = normalize_policy_identifier(end_raw)

    if norm_coi == norm_end:
        has_citations = (coi_evidence is not None and endorsement_evidence is not None)
        if has_citations:
            return PolicyReconciliationRecord(
                coi_document_id=coi_document_id,
                coi_policy_number=coi_policy_number,
                coi_evidence=coi_evidence,
                endorsement_document_id=endorsement_document_id,
                endorsement_policy_number=endorsement_policy_number,
                endorsement_evidence=endorsement_evidence,
                classification=PolicyMatchClassification.FORMATTING_NORMALIZED,
                evidence_chain=evidence_chain,
                is_confirmed_match=True,
                requires_human_review=False,
                review_reason_code=None,
            )
        else:
            return PolicyReconciliationRecord(
                coi_document_id=coi_document_id,
                coi_policy_number=coi_policy_number,
                coi_evidence=coi_evidence,
                endorsement_document_id=endorsement_document_id,
                endorsement_policy_number=endorsement_policy_number,
                endorsement_evidence=endorsement_evidence,
                classification=PolicyMatchClassification.AMBIGUOUS,
                evidence_chain=evidence_chain,
                is_confirmed_match=False,
                requires_human_review=True,
                review_reason_code="POLICY_NUMBER_MISSING_EVIDENCE",
            )

    # 4. Possible Family Match (shared base with differing renewal suffix or leading zeros)
    if _is_possible_policy_family(norm_coi, norm_end):
        return PolicyReconciliationRecord(
            coi_document_id=coi_document_id,
            coi_policy_number=coi_policy_number,
            coi_evidence=coi_evidence,
            endorsement_document_id=endorsement_document_id,
            endorsement_policy_number=endorsement_policy_number,
            endorsement_evidence=endorsement_evidence,
            classification=PolicyMatchClassification.POSSIBLE_FAMILY,
            evidence_chain=evidence_chain,
            is_confirmed_match=False,
            requires_human_review=True,
            review_reason_code="POTENTIAL_POLICY_FAMILY_RENEWAL_MISMATCH",
        )

    # 5. Distinct / Conflicting policy numbers
    return PolicyReconciliationRecord(
        coi_document_id=coi_document_id,
        coi_policy_number=coi_policy_number,
        coi_evidence=coi_evidence,
        endorsement_document_id=endorsement_document_id,
        endorsement_policy_number=endorsement_policy_number,
        endorsement_evidence=endorsement_evidence,
        classification=PolicyMatchClassification.CONFLICTING,
        evidence_chain=evidence_chain,
        is_confirmed_match=False,
        requires_human_review=True,
        review_reason_code="CONFLICTING_POLICY_IDENTIFIERS",
    )


# =============================================================================
# 2. Entity Identity Reconciliation (Independent of Document Roles)
# =============================================================================

def reconcile_entity_identities(
    primary_entity_name: Optional[str],
    primary_entity_role: EntityRole,
    primary_document_id: str,
    referenced_entity_name: Optional[str],
    referenced_entity_role: EntityRole,
    referenced_document_id: str,
    applicable_contract_requirement_id: Optional[str] = None,
    dba_evidence: Optional[EvidenceReference] = None,
    evidence_chain: Tuple[EvidenceReference, ...] = (),
) -> EntityReconciliationRecord:
    """Deterministically reconcile legal identity between two entities.
    
    Architectural Invariant:
    Legal identity and document roles are evaluated INDEPENDENTLY.
    - Two records representing the same legal entity (e.g. 'Apex Electrical LLC')
      may appear as NAMED_INSURED on a COI and ADDITIONAL_INSURED on an endorsement.
      Their identity is EXACT or FORMATTING_NORMALIZED.
    - Never classify two entities as DISTINCT_LEGAL_ENTITY solely because their
      document roles differ.
    - Contractual role satisfaction is evaluated separately.
    """
    p_raw = (primary_entity_name or "").strip()
    r_raw = (referenced_entity_name or "").strip()

    # Missing entity names
    if not p_raw or not r_raw:
        return EntityReconciliationRecord(
            primary_entity_name=p_raw,
            primary_entity_role=primary_entity_role,
            primary_document_id=primary_document_id,
            referenced_entity_name=r_raw,
            referenced_entity_role=referenced_entity_role,
            referenced_document_id=referenced_document_id,
            classification=EntityMatchClassification.AMBIGUOUS_IDENTITY,
            applicable_contract_requirement_id=applicable_contract_requirement_id,
            evidence_chain=evidence_chain,
            is_confirmed_match=False,
            requires_human_review=True,
            review_reason_code="MISSING_ENTITY_NAME",
        )

    # Evidence coverage check (both documents present in chain)
    doc_ids_in_evidence = {ref.document_id for ref in evidence_chain}
    has_dual_evidence = (
        primary_document_id in doc_ids_in_evidence and referenced_document_id in doc_ids_in_evidence
    )

    cleaned_p = _clean_entity_name(p_raw)
    cleaned_r = _clean_entity_name(r_raw)

    # 1. Exact string match (character-for-character, case-sensitive)
    if cleaned_p == cleaned_r:
        if has_dual_evidence:
            return EntityReconciliationRecord(
                primary_entity_name=p_raw,
                primary_entity_role=primary_entity_role,
                primary_document_id=primary_document_id,
                referenced_entity_name=r_raw,
                referenced_entity_role=referenced_entity_role,
                referenced_document_id=referenced_document_id,
                classification=EntityMatchClassification.EXACT,
                applicable_contract_requirement_id=applicable_contract_requirement_id,
                evidence_chain=evidence_chain,
                is_confirmed_match=True,
                requires_human_review=False,
                review_reason_code=None,
            )
        else:
            return EntityReconciliationRecord(
                primary_entity_name=p_raw,
                primary_entity_role=primary_entity_role,
                primary_document_id=primary_document_id,
                referenced_entity_name=r_raw,
                referenced_entity_role=referenced_entity_role,
                referenced_document_id=referenced_document_id,
                classification=EntityMatchClassification.AMBIGUOUS_IDENTITY,
                applicable_contract_requirement_id=applicable_contract_requirement_id,
                evidence_chain=evidence_chain,
                is_confirmed_match=False,
                requires_human_review=True,
                review_reason_code="INSUFFICIENT_EVIDENCE_FOR_CONFIRMATION",
            )

    # 2. Case-insensitive exact match
    if cleaned_p.lower() == cleaned_r.lower():
        if has_dual_evidence:
            return EntityReconciliationRecord(
                primary_entity_name=p_raw,
                primary_entity_role=primary_entity_role,
                primary_document_id=primary_document_id,
                referenced_entity_name=r_raw,
                referenced_entity_role=referenced_entity_role,
                referenced_document_id=referenced_document_id,
                classification=EntityMatchClassification.FORMATTING_NORMALIZED,
                applicable_contract_requirement_id=applicable_contract_requirement_id,
                evidence_chain=evidence_chain,
                is_confirmed_match=True,
                requires_human_review=False,
                review_reason_code=None,
            )
        else:
            return EntityReconciliationRecord(
                primary_entity_name=p_raw,
                primary_entity_role=primary_entity_role,
                primary_document_id=primary_document_id,
                referenced_entity_name=r_raw,
                referenced_entity_role=referenced_entity_role,
                referenced_document_id=referenced_document_id,
                classification=EntityMatchClassification.AMBIGUOUS_IDENTITY,
                applicable_contract_requirement_id=applicable_contract_requirement_id,
                evidence_chain=evidence_chain,
                is_confirmed_match=False,
                requires_human_review=True,
                review_reason_code="INSUFFICIENT_EVIDENCE_FOR_CONFIRMATION",
            )

    # 3. Formatting-normalized suffix check (e.g. 'Apex Electrical, LLC.' vs 'Apex Electrical LLC')
    core_p, suff_p = _split_core_and_suffix(cleaned_p)
    core_r, suff_r = _split_core_and_suffix(cleaned_r)

    if core_p and core_r and core_p == core_r:
        if suff_p == suff_r and suff_p is not None:
            if has_dual_evidence:
                return EntityReconciliationRecord(
                    primary_entity_name=p_raw,
                    primary_entity_role=primary_entity_role,
                    primary_document_id=primary_document_id,
                    referenced_entity_name=r_raw,
                    referenced_entity_role=referenced_entity_role,
                    referenced_document_id=referenced_document_id,
                    classification=EntityMatchClassification.FORMATTING_NORMALIZED,
                    applicable_contract_requirement_id=applicable_contract_requirement_id,
                    evidence_chain=evidence_chain,
                    is_confirmed_match=True,
                    requires_human_review=False,
                    review_reason_code=None,
                )
            else:
                return EntityReconciliationRecord(
                    primary_entity_name=p_raw,
                    primary_entity_role=primary_entity_role,
                    primary_document_id=primary_document_id,
                    referenced_entity_name=r_raw,
                    referenced_entity_role=referenced_entity_role,
                    referenced_document_id=referenced_document_id,
                    classification=EntityMatchClassification.AMBIGUOUS_IDENTITY,
                    applicable_contract_requirement_id=applicable_contract_requirement_id,
                    evidence_chain=evidence_chain,
                    is_confirmed_match=False,
                    requires_human_review=True,
                    review_reason_code="INSUFFICIENT_EVIDENCE_FOR_CONFIRMATION",
                )
        if suff_p != suff_r and suff_p is not None and suff_r is not None:
            # Different corporate legal forms (e.g. Inc vs LLC)
            return EntityReconciliationRecord(
                primary_entity_name=p_raw,
                primary_entity_role=primary_entity_role,
                primary_document_id=primary_document_id,
                referenced_entity_name=r_raw,
                referenced_entity_role=referenced_entity_role,
                referenced_document_id=referenced_document_id,
                classification=EntityMatchClassification.LEGAL_SUFFIX_DISCREPANCY,
                applicable_contract_requirement_id=applicable_contract_requirement_id,
                evidence_chain=evidence_chain,
                is_confirmed_match=False,
                requires_human_review=True,
                review_reason_code="CORPORATE_SUFFIX_DISCREPANCY",
            )

    # 4. Confirmed DBA Relationship with affirmative evidence
    if dba_evidence is not None:
        chain_with_dba = evidence_chain
        if dba_evidence not in chain_with_dba:
            chain_with_dba = chain_with_dba + (dba_evidence,)
        doc_ids_dba = {ref.document_id for ref in chain_with_dba}
        if primary_document_id in doc_ids_dba and referenced_document_id in doc_ids_dba:
            return EntityReconciliationRecord(
                primary_entity_name=p_raw,
                primary_entity_role=primary_entity_role,
                primary_document_id=primary_document_id,
                referenced_entity_name=r_raw,
                referenced_entity_role=referenced_entity_role,
                referenced_document_id=referenced_document_id,
                classification=EntityMatchClassification.CONFIRMED_DBA,
                applicable_contract_requirement_id=applicable_contract_requirement_id,
                dba_evidence=dba_evidence,
                evidence_chain=chain_with_dba,
                is_confirmed_match=True,
                requires_human_review=False,
                review_reason_code=None,
            )

    # 5. Ambiguous Trade / Partial Names
    p_lower = cleaned_p.lower()
    r_lower = cleaned_r.lower()
    is_ambiguous = (
        (core_p and core_r and (core_p in core_r or core_r in core_p))
        or (p_lower in r_lower or r_lower in p_lower)
        or ("dba" in p_lower or "dba" in r_lower)
    )

    if is_ambiguous:
        return EntityReconciliationRecord(
            primary_entity_name=p_raw,
            primary_entity_role=primary_entity_role,
            primary_document_id=primary_document_id,
            referenced_entity_name=r_raw,
            referenced_entity_role=referenced_entity_role,
            referenced_document_id=referenced_document_id,
            classification=EntityMatchClassification.AMBIGUOUS_IDENTITY,
            applicable_contract_requirement_id=applicable_contract_requirement_id,
            evidence_chain=evidence_chain,
            is_confirmed_match=False,
            requires_human_review=True,
            review_reason_code="AMBIGUOUS_TRADE_OR_PARTIAL_NAME",
        )

    # 6. Genuinely Different Legal Entities
    if applicable_contract_requirement_id and evidence_chain:
        return EntityReconciliationRecord(
            primary_entity_name=p_raw,
            primary_entity_role=primary_entity_role,
            primary_document_id=primary_document_id,
            referenced_entity_name=r_raw,
            referenced_entity_role=referenced_entity_role,
            referenced_document_id=referenced_document_id,
            classification=EntityMatchClassification.CONFIRMED_MISMATCH,
            applicable_contract_requirement_id=applicable_contract_requirement_id,
            evidence_chain=evidence_chain,
            is_confirmed_match=False,
            requires_human_review=False,
            review_reason_code="AFFIRMATIVE_CONTRACTUAL_ENTITY_MISMATCH",
        )

    return EntityReconciliationRecord(
        primary_entity_name=p_raw,
        primary_entity_role=primary_entity_role,
        primary_document_id=primary_document_id,
        referenced_entity_name=r_raw,
        referenced_entity_role=referenced_entity_role,
        referenced_document_id=referenced_document_id,
        classification=EntityMatchClassification.DISTINCT_LEGAL_ENTITY,
        applicable_contract_requirement_id=applicable_contract_requirement_id,
        evidence_chain=evidence_chain,
        is_confirmed_match=False,
        requires_human_review=True,
        review_reason_code="DISTINCT_LEGAL_ENTITIES",
    )


# =============================================================================
# 3. Contractual Role Satisfaction Verification
# =============================================================================

def check_contractual_role_satisfaction(
    entity_record: EntityReconciliationRecord,
    required_entity_name: Optional[str],
    required_role: Optional[EntityRole],
    contract_requirement_id: Optional[str],
    coverage_type: Optional[CoverageType] = None,
) -> Tuple[bool, Optional[DocumentDiscrepancy]]:
    """Verify whether an entity satisfies a specific contractual role requirement.
    
    Guarantees:
    - Named Insured, General Contractor, Additional Insured, Certificate Holder
      are NEVER treated as interchangeable.
    - A role mismatch alone without a validated contractual requirement must NOT
      create a confirmed violation.
    - If evidence is missing or inadequate, returns an unresolved outcome,
      never an unproven confirmed violation.
    - CONFIRMED_MISMATCH does NOT independently establish a violation without
      a validated contractual requirement and supporting evidence.
    
    Returns:
        (is_satisfied, optional_discrepancy)
    """
    # 1. Require validated contractual requirement
    if not contract_requirement_id or not contract_requirement_id.strip():
        # No contractual requirement validated -> cannot establish a confirmed contractual violation!
        return False, None

    if not required_entity_name or not required_entity_name.strip() or required_role is None:
        # Incomplete requirement parameters -> cannot determine violation
        return False, None

    # 2. Evidence adequacy check
    if not entity_record.evidence_chain:
        # Required role/identity is not adequately evidenced
        disc = DocumentDiscrepancy(
            discrepancy_id=f"disc_missing_evidence_{contract_requirement_id}",
            category=DiscrepancyCategory.MISSING_EVIDENCE,
            severity=Severity.MAJOR,
            reason_code="INSUFFICIENT_ROLE_EVIDENCE",
            description=(
                f"Contractual requirement '{contract_requirement_id}' requires entity '{required_entity_name}' "
                f"in role '{required_role.value}', but evidence is missing or insufficient."
            ),
            source_document_id=entity_record.primary_document_id,
            conflicting_document_id=entity_record.referenced_document_id,
            applicable_requirement_id=contract_requirement_id,
            applicable_entity_role=required_role,
            applicable_coverage_type=coverage_type,
            evidence_chain=(),
            requires_human_review=True,
        )
        return False, disc

    # 3. Strict Functional Role Verification
    if entity_record.primary_entity_role != required_role:
        disc = DocumentDiscrepancy(
            discrepancy_id=f"disc_role_{contract_requirement_id}",
            category=DiscrepancyCategory.CONFIRMED_CONTRACTUAL_VIOLATION,
            severity=Severity.CRITICAL,
            reason_code="CONTRACTUAL_ROLE_MISMATCH",
            description=(
                f"Entity '{entity_record.primary_entity_name}' appears as role '{entity_record.primary_entity_role.value}', "
                f"which does not satisfy required contractual role '{required_role.value}' for {contract_requirement_id}."
            ),
            source_document_id=entity_record.primary_document_id,
            conflicting_document_id=entity_record.referenced_document_id,
            applicable_requirement_id=contract_requirement_id,
            applicable_entity_role=required_role,
            applicable_coverage_type=coverage_type,
            evidence_chain=entity_record.evidence_chain,
            requires_human_review=True,
        )
        return False, disc

    # 4. Legal Entity Name Match Verification
    is_name_match, match_reason = compare_entity_names(
        entity_record.primary_entity_name,
        required_entity_name,
        require_exact=False,
    )

    if entity_record.is_confirmed_match and is_name_match:
        return True, None

    # Corporate suffix discrepancy -> Document Discrepancy (requires human review, not proven violation)
    if entity_record.classification == EntityMatchClassification.LEGAL_SUFFIX_DISCREPANCY:
        disc = DocumentDiscrepancy(
            discrepancy_id=f"disc_suffix_{contract_requirement_id}",
            category=DiscrepancyCategory.DOCUMENT_DISCREPANCY,
            severity=Severity.MAJOR,
            reason_code="CORPORATE_SUFFIX_DISCREPANCY",
            description=(
                f"Corporate suffix discrepancy between '{entity_record.primary_entity_name}' and "
                f"required entity '{required_entity_name}' for requirement '{contract_requirement_id}'."
            ),
            source_document_id=entity_record.primary_document_id,
            conflicting_document_id=entity_record.referenced_document_id,
            applicable_requirement_id=contract_requirement_id,
            applicable_entity_role=required_role,
            applicable_coverage_type=coverage_type,
            evidence_chain=entity_record.evidence_chain,
            requires_human_review=True,
        )
        return False, disc

    # Confirmed mismatch with evidence -> Confirmed Contractual Violation
    if entity_record.classification == EntityMatchClassification.CONFIRMED_MISMATCH or not is_name_match:
        disc = DocumentDiscrepancy(
            discrepancy_id=f"disc_mismatch_{contract_requirement_id}",
            category=DiscrepancyCategory.CONFIRMED_CONTRACTUAL_VIOLATION,
            severity=Severity.CRITICAL,
            reason_code="CONFIRMED_NAMED_INSURED_VIOLATION",
            description=(
                f"Confirmed entity mismatch: entity '{entity_record.primary_entity_name}' does not match "
                f"required entity '{required_entity_name}' for requirement '{contract_requirement_id}'."
            ),
            source_document_id=entity_record.primary_document_id,
            conflicting_document_id=entity_record.referenced_document_id,
            applicable_requirement_id=contract_requirement_id,
            applicable_entity_role=required_role,
            applicable_coverage_type=coverage_type,
            evidence_chain=entity_record.evidence_chain,
            requires_human_review=True,
        )
        return False, disc

    # Ambiguous / unverified relationship -> Ambiguous Discrepancy (requires human review)
    disc = DocumentDiscrepancy(
        discrepancy_id=f"disc_ambiguous_{contract_requirement_id}",
        category=DiscrepancyCategory.AMBIGUOUS_RELATIONSHIP,
        severity=Severity.MAJOR,
        reason_code=entity_record.review_reason_code or "AMBIGUOUS_ENTITY_RELATIONSHIP",
        description=(
            f"Unresolved entity relationship ({entity_record.classification.value}) for "
            f"'{entity_record.primary_entity_name}' against required '{required_entity_name}'."
        ),
        source_document_id=entity_record.primary_document_id,
        conflicting_document_id=entity_record.referenced_document_id,
        applicable_requirement_id=contract_requirement_id,
        applicable_entity_role=required_role,
        applicable_coverage_type=coverage_type,
        evidence_chain=entity_record.evidence_chain,
        requires_human_review=True,
    )
    return False, disc


# =============================================================================
# 4. Temporal Date Reconciliation
# =============================================================================

def reconcile_dates(
    policy_effective_date: Optional[date],
    policy_expiration_date: Optional[date],
    policy_date_evidence: Tuple[EvidenceReference, ...],
    endorsement_effective_date: Optional[date],
    endorsement_expiration_date: Optional[date],
    endorsement_date_evidence: Tuple[EvidenceReference, ...],
    evaluation_date: Optional[date] = None,
    policy_document_id: Optional[str] = None,
    endorsement_document_id: Optional[str] = None,
    evidence_chain: Tuple[EvidenceReference, ...] = (),
    contractual_duration_requirement_id: Optional[str] = None,
) -> DateReconciliationRecord:
    """Deterministically reconcile policy and endorsement validity periods.
    
    Guarantees:
    - Active/inactive conclusions strictly require complete, verified dates AND
      a defined evaluation date.
    - Missing evaluation date produces is_policy_active=None and is_endorsement_active=None.
    - An endorsement that expires before the policy may still be active on the evaluation date.
      Do NOT automatically flag an active endorsement as noncompliant merely because
      the policy expires later.
    - An expired endorsement requires adequate date evidence before concluding inactive.
    - Inverted dates trigger immediate ValueError.
    """
    # Active state evaluation requires defined evaluation date
    is_policy_active: Optional[bool] = None
    is_endorsement_active: Optional[bool] = None

    if evaluation_date is not None:
        if policy_effective_date is not None and policy_expiration_date is not None:
            if policy_effective_date <= evaluation_date <= policy_expiration_date:
                is_policy_active = True
            else:
                is_policy_active = False

        if endorsement_effective_date is not None and endorsement_expiration_date is not None:
            if endorsement_effective_date <= evaluation_date <= endorsement_expiration_date:
                is_endorsement_active = True
            else:
                is_endorsement_active = False

    # Midterm addition
    is_midterm: Optional[bool] = None
    if endorsement_effective_date is not None and policy_effective_date is not None:
        is_midterm = endorsement_effective_date > policy_effective_date

    # Premature expiration relative to underlying policy
    is_premature: Optional[bool] = None
    if endorsement_expiration_date is not None and policy_expiration_date is not None:
        if endorsement_expiration_date < policy_expiration_date:
            if is_endorsement_active is not None:
                is_premature = True
        else:
            is_premature = False

    # Review & Discrepancy Derivation:
    # An active endorsement expiring before policy is NOT an automatic confirmed violation
    # unless an explicit contractual duration requirement is violated or it is inactive!
    requires_review = False
    discrepancy_cat: Optional[DiscrepancyCategory] = None
    reason_code: Optional[str] = None

    if is_policy_active is False:
        requires_review = True
        discrepancy_cat = DiscrepancyCategory.DOCUMENT_DISCREPANCY
        reason_code = "POLICY_INACTIVE_ON_EVALUATION_DATE"
    elif is_endorsement_active is False:
        requires_review = True
        discrepancy_cat = DiscrepancyCategory.DOCUMENT_DISCREPANCY
        reason_code = "ENDORSEMENT_INACTIVE_ON_EVALUATION_DATE"
    elif is_premature is True and contractual_duration_requirement_id is not None:
        # Explicit contractual duration requirement violated
        requires_review = True
        discrepancy_cat = DiscrepancyCategory.CONFIRMED_CONTRACTUAL_VIOLATION
        reason_code = "PREMATURE_EXPIRATION_VIOLATION"

    return DateReconciliationRecord(
        policy_document_id=policy_document_id,
        policy_effective_date=policy_effective_date,
        policy_expiration_date=policy_expiration_date,
        policy_date_evidence=policy_date_evidence,
        endorsement_document_id=endorsement_document_id,
        endorsement_effective_date=endorsement_effective_date,
        endorsement_expiration_date=endorsement_expiration_date,
        endorsement_date_evidence=endorsement_date_evidence,
        evaluation_date=evaluation_date,
        is_midterm_addition=is_midterm,
        is_policy_active_on_evaluation_date=is_policy_active,
        is_endorsement_active_on_evaluation_date=is_endorsement_active,
        is_premature_expiration=is_premature,
        requires_human_review=requires_review,
        discrepancy_category=discrepancy_cat,
        review_reason_code=reason_code,
        evidence_chain=evidence_chain,
    )


# =============================================================================
# 5. Relationship Classification with Relationship-Specific Evidence
# =============================================================================

def classify_document_relationship(
    edge_id: str,
    source_document_id: str,
    target_document_id: Optional[str],
    relationship_type: DocumentRelationshipType,
    classification: EdgeClassification,
    is_compliance_relevant: bool = True,
    evidence_references: Tuple[EvidenceReference, ...] = (),
    associated_policy_id: Optional[str] = None,
    coverage_type: Optional[CoverageType] = None,
    has_relationship_evidence: bool = True,
    requires_human_review: Optional[bool] = None,
    review_reason_code: Optional[str] = None,
) -> DocumentRelationshipEdge:
    """Build a validated directional relationship edge between documents.
    
    Guarantees:
    - Matching policy numbers alone DO NOT confirm replacement, amendment, or duplicate.
      Explicit relationship-specific evidence is required.
    - Confirmed edges require valid affirmative evidence for both source and target documents.
    - Unsupported relationships remain unresolved / require human review.
    """
    if relationship_type == DocumentRelationshipType.ORPHAN_DOCUMENT:
        return DocumentRelationshipEdge(
            edge_id=edge_id,
            source_document_id=source_document_id,
            target_document_id=None,
            relationship_type=DocumentRelationshipType.ORPHAN_DOCUMENT,
            classification=EdgeClassification.UNLINKED_ORPHAN,
            is_compliance_relevant=is_compliance_relevant,
            evidence_references=evidence_references,
            is_confirmed=False,
            requires_human_review=True,
            review_reason_code=review_reason_code or "ORPHAN_DOCUMENT_NO_POLICY_LINK",
        )

    # For replacement, amendment, and duplicate: relationship-specific evidence is mandatory for confirmation
    if relationship_type in (
        DocumentRelationshipType.REPLACES_DOCUMENT,
        DocumentRelationshipType.AMENDS_DOCUMENT,
        DocumentRelationshipType.DUPLICATE_OF,
    ):
        if not has_relationship_evidence:
            return DocumentRelationshipEdge(
                edge_id=edge_id,
                source_document_id=source_document_id,
                target_document_id=target_document_id,
                relationship_type=relationship_type,
                associated_policy_id=associated_policy_id,
                coverage_type=coverage_type,
                classification=EdgeClassification.AMBIGUOUS,
                is_compliance_relevant=is_compliance_relevant,
                evidence_references=evidence_references,
                is_confirmed=False,
                requires_human_review=True,
                review_reason_code="UNSUPPORTED_RELATIONSHIP_ASSERTION",
            )

    is_confirmed = classification in (
        EdgeClassification.CONFIRMED_EXACT,
        EdgeClassification.CONFIRMED_NORMALIZED,
        EdgeClassification.CONFIRMED_DBA,
    )
    if requires_human_review is None:
        requires_human_review = not is_confirmed

    return DocumentRelationshipEdge(
        edge_id=edge_id,
        source_document_id=source_document_id,
        target_document_id=target_document_id,
        relationship_type=relationship_type,
        associated_policy_id=associated_policy_id,
        coverage_type=coverage_type,
        classification=classification,
        is_compliance_relevant=is_compliance_relevant,
        evidence_references=evidence_references,
        is_confirmed=is_confirmed,
        requires_human_review=requires_human_review,
        review_reason_code=review_reason_code,
    )


# =============================================================================
# 6. Deterministic Reconciliation Engine
# =============================================================================

class DeterministicReconciliationEngine:
    """Deterministic, rule-based cross-document reconciliation engine.
    
    Operates without AI in the decision path: takes extracted documents,
    packet manifest, and contractual requirements to build a fully validated,
    immutable CrossDocumentReconciliationResult.
    """

    def reconcile_packet(
        self,
        document_packet_id: str,
        packet_manifest: Tuple[DocumentManifestEntry, ...],
        primary_coi_id: Optional[str] = None,
        graph_edges: Tuple[DocumentRelationshipEdge, ...] = (),
        entity_records: Tuple[EntityReconciliationRecord, ...] = (),
        policy_records: Tuple[PolicyReconciliationRecord, ...] = (),
        date_records: Tuple[DateReconciliationRecord, ...] = (),
        missing_evidence_records: Tuple[MissingEvidenceProvenance, ...] = (),
        discrepancies: Tuple[DocumentDiscrepancy, ...] = (),
    ) -> CrossDocumentReconciliationResult:
        """Construct and validate complete immutable reconciliation result."""
        return CrossDocumentReconciliationResult(
            document_packet_id=document_packet_id,
            primary_coi_id=primary_coi_id,
            packet_manifest=packet_manifest,
            graph_edges=graph_edges,
            entity_records=entity_records,
            policy_records=policy_records,
            date_records=date_records,
            missing_evidence_records=missing_evidence_records,
            discrepancies=discrepancies,
        )


__all__ = [
    "reconcile_policy_identifiers",
    "reconcile_entity_identities",
    "check_contractual_role_satisfaction",
    "reconcile_dates",
    "classify_document_relationship",
    "DeterministicReconciliationEngine",
]
