"""Deterministic Cross-Document Reconciliation Logic.

Architectural Invariant:
'AI extracts information. Deterministic Python rules evaluate it. Humans resolve uncertainty.'

This module implements the deterministic reconciliation stage between document extraction
and compliance evaluation:
1. Entity identity reconciliation (independent of document roles)
2. Contractual role compatibility and contractual-role satisfaction
3. Policy identifier reconciliation (strict 5-tier classification)
4. Temporal date reconciliation with nullable active states
5. Multi-edge document relationship graph classification with relationship-specific evidence
6. Cross-document evidence and referential integrity validation
7. Deterministic summary derivation
"""
from __future__ import annotations

import re
from datetime import date
from typing import Dict, List, Optional, Set, Tuple

from app.compliance.evaluator import _clean_entity_name, _split_core_and_suffix, compare_entity_names
from app.schemas.insurance import (
    CoverageType,
    DocumentType,
    EvidenceReference,
    Severity,
)
from app.schemas.reconciliation import (
    AMENDS_EVIDENCE_PATTERN,
    DECLARATION_EVIDENCE_PATTERN,
    DUPLICATE_EVIDENCE_PATTERN,
    ENDORSEMENT_EVIDENCE_PATTERN,
    POLICY_COVERAGE_EVIDENCE_PATTERN,
    REPLACES_EVIDENCE_PATTERN,
    CrossDocumentReconciliationResult,
    DateReconciliationRecord,
    DiscrepancyCategory,
    DocumentDiscrepancy,
    DocumentManifestEntry,
    DocumentRelationshipEdge,
    DocumentRelationshipType,
    EdgeClassification,
    EntityMatchClassification,
    EntityReconciliationRecord,
    EntityRole,
    GraphEvaluationStatus,
    MissingEvidenceProvenance,
    PolicyMatchClassification,
    PolicyReconciliationRecord,
    is_role_compatible,
    normalize_policy_identifier,
    validate_evidence_reference,
)


# =============================================================================
# 1. Policy Number Reconciliation
# =============================================================================

RENEWAL_SUFFIX_REGEX = re.compile(
    r"[-_/](0[1-9]|[1-9][0-9]?|20[2-9][0-9]|R[0-9]+|RN[0-9]+|TERM[0-9]+)$",
    re.IGNORECASE,
)

def _is_possible_policy_family(raw_a: str, raw_b: str) -> bool:
    """Detect if two policy identifiers share a common base with a documented renewal pattern.
    
    Conservative policy-family classification (Correction 3):
    - Leading-zero differences alone do NOT infer family (they classify as CONFLICTING/AMBIGUOUS).
    - Arbitrary shared prefixes do NOT infer family.
    - Only documented renewal patterns (e.g. -01 vs -02, /2024 vs /2025, -R1 vs -R2, -TERM1 vs -TERM2)
      on an identical base qualify as POSSIBLE_FAMILY.
    - Arbitrary alphanumeric suffix differences without renewal evidence are rejected.
    """
    if not raw_a or not raw_b:
        return False

    a = raw_a.strip().upper()
    b = raw_b.strip().upper()

    if a == b:
        return False

    m_a = RENEWAL_SUFFIX_REGEX.search(a)
    m_b = RENEWAL_SUFFIX_REGEX.search(b)

    # Both have documented renewal suffixes sharing the identical base
    if m_a and m_b:
        base_a = a[: m_a.start()]
        base_b = b[: m_b.start()]
        if base_a == base_b and len(base_a) >= 3:
            return True

    # One has a renewal suffix, the other is the exact common base
    if m_a and not m_b:
        base_a = a[: m_a.start()]
        if base_a == b and len(base_a) >= 3:
            return True

    if m_b and not m_a:
        base_b = b[: m_b.start()]
        if base_b == a and len(base_b) >= 3:
            return True

    return False


def reconcile_policy_identifiers(
    coi_document_id: str,
    coi_policy_number: Optional[str],
    coi_evidence: Optional[EvidenceReference],
    endorsement_document_id: str,
    endorsement_policy_number: Optional[str],
    endorsement_evidence: Optional[EvidenceReference],
    evidence_chain: Optional[Tuple[EvidenceReference, ...]] = None,
) -> PolicyReconciliationRecord:
    r"""Deterministically reconcile policy numbers between a COI and an Endorsement.
    
    Enforces the strict 5-tier classification:
    - EXACT: character-for-character identical strings
    - FORMATTING_NORMALIZED: identical after permitted delimiter stripping, differing raw
    - POSSIBLE_FAMILY: common base with differing renewal/term suffix or leading zeros (requires review)
    - AMBIGUOUS: missing or unparseable policy numbers (requires review)
    - CONFLICTING: distinct, incompatible policy numbers (requires review)
    
    Normalization Rules:
    - Strips permitted delimiter characters: whitespace, hyphens, slashes, periods: [\\s\\-\\/\.]
    - Converts to uppercase.
    - Preserves all alphanumeric characters, leading zeros, sequence numbers,
      and renewal/term suffixes.
    - Does NOT remove leading zeros (e.g. '0012345' is NOT converted to '12345').
    - Does NOT remove renewal suffixes (e.g. '-01', '-02' are preserved).
    """
    coi_raw = (coi_policy_number or "").strip()
    end_raw = (endorsement_policy_number or "").strip()

    # Determine default evidence chain if omitted
    if evidence_chain is None:
        chain_refs: List[EvidenceReference] = []
        if coi_evidence is not None:
            chain_refs.append(coi_evidence)
        if endorsement_evidence is not None:
            chain_refs.append(endorsement_evidence)
        evidence_chain = tuple(chain_refs)

    # 1. Missing or unparseable policy numbers
    if not coi_raw or not end_raw:
        return PolicyReconciliationRecord(
            coi_document_id=coi_document_id,
            coi_policy_number=coi_policy_number,
            coi_evidence=coi_evidence,
            endorsement_document_id=endorsement_document_id,
            endorsement_policy_number=endorsement_policy_number,
            endorsement_evidence=endorsement_evidence,
            classification=PolicyMatchClassification.AMBIGUOUS,
            evidence_chain=evidence_chain,
            is_confirmed_match=False,
            requires_human_review=True,
            review_reason_code="MISSING_OR_UNPARSEABLE_POLICY_NUMBER",
        )

    # 2. EXACT character-for-character match
    if coi_raw == end_raw:
        has_citations = (coi_evidence is not None and endorsement_evidence is not None)
        if has_citations:
            return PolicyReconciliationRecord(
                coi_document_id=coi_document_id,
                coi_policy_number=coi_policy_number,
                coi_evidence=coi_evidence,
                endorsement_document_id=endorsement_document_id,
                endorsement_policy_number=endorsement_policy_number,
                endorsement_evidence=endorsement_evidence,
                classification=PolicyMatchClassification.EXACT,
                evidence_chain=evidence_chain,
                is_confirmed_match=True,
                requires_human_review=False,
                review_reason_code=None,
            )
        else:
            return PolicyReconciliationRecord(
                coi_document_id=coi_document_id,
                coi_policy_number=coi_policy_number,
                coi_evidence=coi_evidence,
                endorsement_document_id=endorsement_document_id,
                endorsement_policy_number=endorsement_policy_number,
                endorsement_evidence=endorsement_evidence,
                classification=PolicyMatchClassification.AMBIGUOUS,
                evidence_chain=evidence_chain,
                is_confirmed_match=False,
                requires_human_review=True,
                review_reason_code="POLICY_NUMBER_MISSING_EVIDENCE",
            )

    # 3. Delimiter-normalized match
    norm_coi = normalize_policy_identifier(coi_raw)
    norm_end = normalize_policy_identifier(end_raw)

    if norm_coi == norm_end:
        has_citations = (coi_evidence is not None and endorsement_evidence is not None)
        if has_citations:
            return PolicyReconciliationRecord(
                coi_document_id=coi_document_id,
                coi_policy_number=coi_policy_number,
                coi_evidence=coi_evidence,
                endorsement_document_id=endorsement_document_id,
                endorsement_policy_number=endorsement_policy_number,
                endorsement_evidence=endorsement_evidence,
                classification=PolicyMatchClassification.FORMATTING_NORMALIZED,
                evidence_chain=evidence_chain,
                is_confirmed_match=True,
                requires_human_review=False,
                review_reason_code=None,
            )
        else:
            return PolicyReconciliationRecord(
                coi_document_id=coi_document_id,
                coi_policy_number=coi_policy_number,
                coi_evidence=coi_evidence,
                endorsement_document_id=endorsement_document_id,
                endorsement_policy_number=endorsement_policy_number,
                endorsement_evidence=endorsement_evidence,
                classification=PolicyMatchClassification.AMBIGUOUS,
                evidence_chain=evidence_chain,
                is_confirmed_match=False,
                requires_human_review=True,
                review_reason_code="POLICY_NUMBER_MISSING_EVIDENCE",
            )

    # 4. Possible Family Match (documented renewal suffix pattern on identical base)
    if _is_possible_policy_family(coi_raw, end_raw):
        return PolicyReconciliationRecord(
            coi_document_id=coi_document_id,
            coi_policy_number=coi_policy_number,
            coi_evidence=coi_evidence,
            endorsement_document_id=endorsement_document_id,
            endorsement_policy_number=endorsement_policy_number,
            endorsement_evidence=endorsement_evidence,
            classification=PolicyMatchClassification.POSSIBLE_FAMILY,
            evidence_chain=evidence_chain,
            is_confirmed_match=False,
            requires_human_review=True,
            review_reason_code="POTENTIAL_POLICY_FAMILY_RENEWAL_MISMATCH",
        )

    # 5. Distinct / Conflicting policy numbers
    return PolicyReconciliationRecord(
        coi_document_id=coi_document_id,
        coi_policy_number=coi_policy_number,
        coi_evidence=coi_evidence,
        endorsement_document_id=endorsement_document_id,
        endorsement_policy_number=endorsement_policy_number,
        endorsement_evidence=endorsement_evidence,
        classification=PolicyMatchClassification.CONFLICTING,
        evidence_chain=evidence_chain,
        is_confirmed_match=False,
        requires_human_review=True,
        review_reason_code="CONFLICTING_POLICY_IDENTIFIERS",
    )


# =============================================================================
# 2. Entity Identity Reconciliation (Independent of Document Roles)
# =============================================================================

def reconcile_entity_identities(
    primary_entity_name: Optional[str],
    primary_entity_role: EntityRole,
    primary_document_id: str,
    referenced_entity_name: Optional[str],
    referenced_entity_role: EntityRole,
    referenced_document_id: str,
    applicable_contract_requirement_id: Optional[str] = None,
    dba_evidence: Optional[EvidenceReference] = None,
    evidence_chain: Tuple[EvidenceReference, ...] = (),
    primary_role_evidence: Optional[EvidenceReference] = None,
    referenced_role_evidence: Optional[EvidenceReference] = None,
) -> EntityReconciliationRecord:
    """Deterministically reconcile legal identity between two entities.
    
    Architectural Invariant:
    Legal identity and document roles are evaluated INDEPENDENTLY.
    - Two records representing the same legal entity (e.g. 'Apex Electrical LLC')
      may appear as NAMED_INSURED on a COI and ADDITIONAL_INSURED on an endorsement.
      Their identity is EXACT or FORMATTING_NORMALIZED.
    - Never classify two entities as DISTINCT_LEGAL_ENTITY solely because their
      document roles differ.
    - Contractual role satisfaction is evaluated separately.
    - A confirmed mismatch strictly requires affirmative dual-document evidence.
    """
    p_raw = (primary_entity_name or "").strip()
    r_raw = (referenced_entity_name or "").strip()

    # Missing entity names
    if not p_raw or not r_raw:
        return EntityReconciliationRecord(
            primary_entity_name=p_raw,
            primary_entity_role=primary_entity_role,
            primary_document_id=primary_document_id,
            referenced_entity_name=r_raw,
            referenced_entity_role=referenced_entity_role,
            referenced_document_id=referenced_document_id,
            classification=EntityMatchClassification.AMBIGUOUS_IDENTITY,
            applicable_contract_requirement_id=applicable_contract_requirement_id,
            primary_role_evidence=primary_role_evidence,
            referenced_role_evidence=referenced_role_evidence,
            evidence_chain=evidence_chain,
            is_confirmed_match=False,
            requires_human_review=True,
            review_reason_code="MISSING_ENTITY_NAME",
        )

    # Evidence coverage check (both documents present in chain)
    doc_ids_in_evidence = {ref.document_id for ref in evidence_chain}
    has_dual_evidence = (
        primary_document_id in doc_ids_in_evidence and referenced_document_id in doc_ids_in_evidence
    )

    cleaned_p = _clean_entity_name(p_raw)
    cleaned_r = _clean_entity_name(r_raw)

    # 1. Exact string match (character-for-character, case-sensitive)
    if cleaned_p == cleaned_r:
        if has_dual_evidence:
            return EntityReconciliationRecord(
                primary_entity_name=p_raw,
                primary_entity_role=primary_entity_role,
                primary_document_id=primary_document_id,
                referenced_entity_name=r_raw,
                referenced_entity_role=referenced_entity_role,
                referenced_document_id=referenced_document_id,
                classification=EntityMatchClassification.EXACT,
                applicable_contract_requirement_id=applicable_contract_requirement_id,
                primary_role_evidence=primary_role_evidence,
                referenced_role_evidence=referenced_role_evidence,
                evidence_chain=evidence_chain,
                is_confirmed_match=True,
                requires_human_review=False,
                review_reason_code=None,
            )
        else:
            return EntityReconciliationRecord(
                primary_entity_name=p_raw,
                primary_entity_role=primary_entity_role,
                primary_document_id=primary_document_id,
                referenced_entity_name=r_raw,
                referenced_entity_role=referenced_entity_role,
                referenced_document_id=referenced_document_id,
                classification=EntityMatchClassification.AMBIGUOUS_IDENTITY,
                applicable_contract_requirement_id=applicable_contract_requirement_id,
                primary_role_evidence=primary_role_evidence,
                referenced_role_evidence=referenced_role_evidence,
                evidence_chain=evidence_chain,
                is_confirmed_match=False,
                requires_human_review=True,
                review_reason_code="INSUFFICIENT_EVIDENCE_FOR_CONFIRMATION",
            )

    # 2. Case-insensitive exact match
    if cleaned_p.lower() == cleaned_r.lower():
        if has_dual_evidence:
            return EntityReconciliationRecord(
                primary_entity_name=p_raw,
                primary_entity_role=primary_entity_role,
                primary_document_id=primary_document_id,
                referenced_entity_name=r_raw,
                referenced_entity_role=referenced_entity_role,
                referenced_document_id=referenced_document_id,
                classification=EntityMatchClassification.FORMATTING_NORMALIZED,
                applicable_contract_requirement_id=applicable_contract_requirement_id,
                primary_role_evidence=primary_role_evidence,
                referenced_role_evidence=referenced_role_evidence,
                evidence_chain=evidence_chain,
                is_confirmed_match=True,
                requires_human_review=False,
                review_reason_code=None,
            )
        else:
            return EntityReconciliationRecord(
                primary_entity_name=p_raw,
                primary_entity_role=primary_entity_role,
                primary_document_id=primary_document_id,
                referenced_entity_name=r_raw,
                referenced_entity_role=referenced_entity_role,
                referenced_document_id=referenced_document_id,
                classification=EntityMatchClassification.AMBIGUOUS_IDENTITY,
                applicable_contract_requirement_id=applicable_contract_requirement_id,
                primary_role_evidence=primary_role_evidence,
                referenced_role_evidence=referenced_role_evidence,
                evidence_chain=evidence_chain,
                is_confirmed_match=False,
                requires_human_review=True,
                review_reason_code="INSUFFICIENT_EVIDENCE_FOR_CONFIRMATION",
            )

    # 3. Formatting-normalized suffix check (e.g. 'Apex Electrical, LLC.' vs 'Apex Electrical LLC')
    core_p, suff_p = _split_core_and_suffix(cleaned_p)
    core_r, suff_r = _split_core_and_suffix(cleaned_r)

    if core_p and core_r and core_p == core_r:
        if suff_p == suff_r and suff_p is not None:
            if has_dual_evidence:
                return EntityReconciliationRecord(
                    primary_entity_name=p_raw,
                    primary_entity_role=primary_entity_role,
                    primary_document_id=primary_document_id,
                    referenced_entity_name=r_raw,
                    referenced_entity_role=referenced_entity_role,
                    referenced_document_id=referenced_document_id,
                    classification=EntityMatchClassification.FORMATTING_NORMALIZED,
                    applicable_contract_requirement_id=applicable_contract_requirement_id,
                    primary_role_evidence=primary_role_evidence,
                    referenced_role_evidence=referenced_role_evidence,
                    evidence_chain=evidence_chain,
                    is_confirmed_match=True,
                    requires_human_review=False,
                    review_reason_code=None,
                )
            else:
                return EntityReconciliationRecord(
                    primary_entity_name=p_raw,
                    primary_entity_role=primary_entity_role,
                    primary_document_id=primary_document_id,
                    referenced_entity_name=r_raw,
                    referenced_entity_role=referenced_entity_role,
                    referenced_document_id=referenced_document_id,
                    classification=EntityMatchClassification.AMBIGUOUS_IDENTITY,
                    applicable_contract_requirement_id=applicable_contract_requirement_id,
                    primary_role_evidence=primary_role_evidence,
                    referenced_role_evidence=referenced_role_evidence,
                    evidence_chain=evidence_chain,
                    is_confirmed_match=False,
                    requires_human_review=True,
                    review_reason_code="INSUFFICIENT_EVIDENCE_FOR_CONFIRMATION",
                )
        if suff_p != suff_r and suff_p is not None and suff_r is not None:
            # Different corporate legal forms (e.g. Inc vs LLC)
            return EntityReconciliationRecord(
                primary_entity_name=p_raw,
                primary_entity_role=primary_entity_role,
                primary_document_id=primary_document_id,
                referenced_entity_name=r_raw,
                referenced_entity_role=referenced_entity_role,
                referenced_document_id=referenced_document_id,
                classification=EntityMatchClassification.LEGAL_SUFFIX_DISCREPANCY,
                applicable_contract_requirement_id=applicable_contract_requirement_id,
                primary_role_evidence=primary_role_evidence,
                referenced_role_evidence=referenced_role_evidence,
                evidence_chain=evidence_chain,
                is_confirmed_match=False,
                requires_human_review=True,
                review_reason_code="CORPORATE_SUFFIX_DISCREPANCY",
            )

    # 4. Confirmed DBA Relationship with affirmative evidence
    if dba_evidence is not None:
        chain_with_dba = evidence_chain
        if dba_evidence not in chain_with_dba:
            chain_with_dba = chain_with_dba + (dba_evidence,)
        doc_ids_dba = {ref.document_id for ref in chain_with_dba}
        if primary_document_id in doc_ids_dba and referenced_document_id in doc_ids_dba:
            return EntityReconciliationRecord(
                primary_entity_name=p_raw,
                primary_entity_role=primary_entity_role,
                primary_document_id=primary_document_id,
                referenced_entity_name=r_raw,
                referenced_entity_role=referenced_entity_role,
                referenced_document_id=referenced_document_id,
                classification=EntityMatchClassification.CONFIRMED_DBA,
                applicable_contract_requirement_id=applicable_contract_requirement_id,
                dba_evidence=dba_evidence,
                primary_role_evidence=primary_role_evidence,
                referenced_role_evidence=referenced_role_evidence,
                evidence_chain=chain_with_dba,
                is_confirmed_match=True,
                requires_human_review=False,
                review_reason_code=None,
            )

    # 5. Ambiguous Trade / Partial Names
    p_lower = cleaned_p.lower()
    r_lower = cleaned_r.lower()
    is_ambiguous = (
        (core_p and core_r and (core_p in core_r or core_r in core_p))
        or (p_lower in r_lower or r_lower in p_lower)
        or ("dba" in p_lower or "dba" in r_lower)
    )

    if is_ambiguous:
        return EntityReconciliationRecord(
            primary_entity_name=p_raw,
            primary_entity_role=primary_entity_role,
            primary_document_id=primary_document_id,
            referenced_entity_name=r_raw,
            referenced_entity_role=referenced_entity_role,
            referenced_document_id=referenced_document_id,
            classification=EntityMatchClassification.AMBIGUOUS_IDENTITY,
            applicable_contract_requirement_id=applicable_contract_requirement_id,
            primary_role_evidence=primary_role_evidence,
            referenced_role_evidence=referenced_role_evidence,
            evidence_chain=evidence_chain,
            is_confirmed_match=False,
            requires_human_review=True,
            review_reason_code="AMBIGUOUS_TRADE_OR_PARTIAL_NAME",
        )

    # 6. Genuinely Different Legal Entities (Correction D)
    if applicable_contract_requirement_id:
        if has_dual_evidence:
            return EntityReconciliationRecord(
                primary_entity_name=p_raw,
                primary_entity_role=primary_entity_role,
                primary_document_id=primary_document_id,
                referenced_entity_name=r_raw,
                referenced_entity_role=referenced_entity_role,
                referenced_document_id=referenced_document_id,
                classification=EntityMatchClassification.CONFIRMED_MISMATCH,
                applicable_contract_requirement_id=applicable_contract_requirement_id,
                primary_role_evidence=primary_role_evidence,
                referenced_role_evidence=referenced_role_evidence,
                evidence_chain=evidence_chain,
                is_confirmed_match=False,
                requires_human_review=False,
                review_reason_code="AFFIRMATIVE_CONTRACTUAL_ENTITY_MISMATCH",
            )
        else:
            return EntityReconciliationRecord(
                primary_entity_name=p_raw,
                primary_entity_role=primary_entity_role,
                primary_document_id=primary_document_id,
                referenced_entity_name=r_raw,
                referenced_entity_role=referenced_entity_role,
                referenced_document_id=referenced_document_id,
                classification=EntityMatchClassification.AMBIGUOUS_IDENTITY,
                applicable_contract_requirement_id=applicable_contract_requirement_id,
                primary_role_evidence=primary_role_evidence,
                referenced_role_evidence=referenced_role_evidence,
                evidence_chain=evidence_chain,
                is_confirmed_match=False,
                requires_human_review=True,
                review_reason_code="INSUFFICIENT_MISMATCH_EVIDENCE",
            )

    return EntityReconciliationRecord(
        primary_entity_name=p_raw,
        primary_entity_role=primary_entity_role,
        primary_document_id=primary_document_id,
        referenced_entity_name=r_raw,
        referenced_entity_role=referenced_entity_role,
        referenced_document_id=referenced_document_id,
        classification=EntityMatchClassification.DISTINCT_LEGAL_ENTITY,
        applicable_contract_requirement_id=applicable_contract_requirement_id,
        primary_role_evidence=primary_role_evidence,
        referenced_role_evidence=referenced_role_evidence,
        evidence_chain=evidence_chain,
        is_confirmed_match=False,
        requires_human_review=True,
        review_reason_code="DISTINCT_LEGAL_ENTITIES",
    )


# =============================================================================
# 3. Contractual Role Satisfaction Verification
# =============================================================================

ROLE_EVIDENCE_PATTERNS = {
    EntityRole.ADDITIONAL_INSURED: re.compile(
        r"\b(additional\s+insured|included\s+as\s+(an\s+)?additional\s+insured|who\s+is\s+an\s+additional\s+insured|cg\s*20\s*(10|26|37|38|01))\b",
        re.IGNORECASE,
    ),
    EntityRole.NAMED_INSURED: re.compile(
        r"\b(named\s+insured|insured\s*:|insured\s+name|name\s+of\s+insured)\b",
        re.IGNORECASE,
    ),
    EntityRole.CERTIFICATE_HOLDER: re.compile(
        r"\b(certificate\s+holder|holder\s*:)\b",
        re.IGNORECASE,
    ),
}

def _has_role_evidence(
    role: EntityRole,
    doc_id: str,
    record: EntityReconciliationRecord,
    role_ref: Optional[EvidenceReference],
) -> bool:
    """Verify that affirmative role evidence exists for the specified role and document."""
    if role_ref is not None and role_ref.document_id == doc_id:
        return True

    pattern = ROLE_EVIDENCE_PATTERNS.get(role)
    if pattern:
        for ref in record.evidence_chain:
            if ref.document_id == doc_id and ref.source_text:
                if pattern.search(ref.source_text):
                    return True
    return False


def check_contractual_role_satisfaction(
    entity_record: EntityReconciliationRecord,
    required_entity_name: Optional[str],
    required_role: Optional[EntityRole],
    contract_requirement_id: Optional[str],
    coverage_type: Optional[CoverageType] = None,
    is_requirement_validated: bool = True,
) -> Tuple[bool, Optional[DocumentDiscrepancy]]:
    """Verify whether an entity satisfies a specific contractual role requirement.
    
    Guarantees (Correction C):
    - A general entity-name citation must not automatically prove a contractual role.
    - Require evidence supporting the actual role asserted for the relevant entity and document.
    - Preserve the distinction between:
      * Legal entity identity.
      * Document role.
      * Contractual role requirement.
      * Evidence proving that role.
    - A confirmed identity match must not automatically satisfy an additional-insured requirement.
    - Missing role evidence must produce an unresolved/missing-evidence result, not a confirmed violation.
    - An entity mismatch without affirmative evidence produces an unresolved discrepancy,
      not a confirmed violation.
    
    Returns:
        (is_satisfied, optional_discrepancy)
    """
    # 1. Require validated contractual requirement
    if not contract_requirement_id or not contract_requirement_id.strip():
        # No contractual requirement validated -> cannot establish a confirmed contractual violation!
        return False, None

    if not is_requirement_validated:
        # Requirement ID exists but requirement is not validated or applicable -> no confirmed violation
        return False, None

    if not required_entity_name or not required_entity_name.strip() or required_role is None:
        # Incomplete requirement parameters -> cannot determine violation
        return False, None

    # 2. Check entity identity against required_entity_name
    p_name = entity_record.primary_entity_name or ""
    r_name = entity_record.referenced_entity_name or ""
    is_p_match, _ = compare_entity_names(p_name, required_entity_name, require_exact=False)
    is_r_match, _ = compare_entity_names(r_name, required_entity_name, require_exact=False)

    entity_matches_requirement = (
        is_p_match
        or is_r_match
        or (entity_record.is_confirmed_match and (is_p_match or is_r_match))
    )

    # If neither entity matches the contractual requirement
    if not entity_matches_requirement:
        if entity_record.classification == EntityMatchClassification.CONFIRMED_MISMATCH and entity_record.evidence_chain:
            disc = DocumentDiscrepancy(
                discrepancy_id=f"disc_mismatch_{contract_requirement_id}",
                category=DiscrepancyCategory.CONFIRMED_CONTRACTUAL_VIOLATION,
                severity=Severity.CRITICAL,
                reason_code="CONFIRMED_NAMED_INSURED_VIOLATION",
                description=(
                    f"Confirmed entity mismatch: entity '{entity_record.primary_entity_name}' does not match "
                    f"required entity '{required_entity_name}' for requirement '{contract_requirement_id}'."
                ),
                source_document_id=entity_record.primary_document_id,
                conflicting_document_id=entity_record.referenced_document_id,
                applicable_requirement_id=contract_requirement_id,
                applicable_entity_role=required_role,
                applicable_coverage_type=coverage_type,
                evidence_chain=entity_record.evidence_chain,
                requires_human_review=True,
            )
            return False, disc

        # Entity does not match contractual requirement -> unresolved discrepancy, not a role-only violation
        disc = DocumentDiscrepancy(
            discrepancy_id=f"disc_unmatched_entity_{contract_requirement_id}",
            category=DiscrepancyCategory.DOCUMENT_DISCREPANCY,
            severity=Severity.MAJOR,
            reason_code="ENTITY_NAME_MISMATCH",
            description=(
                f"Entity '{entity_record.primary_entity_name}' does not match required entity "
                f"'{required_entity_name}' for requirement '{contract_requirement_id}'."
            ),
            source_document_id=entity_record.primary_document_id,
            conflicting_document_id=entity_record.referenced_document_id,
            applicable_requirement_id=contract_requirement_id,
            applicable_entity_role=required_role,
            applicable_coverage_type=coverage_type,
            evidence_chain=entity_record.evidence_chain,
            requires_human_review=True,
        )
        return False, disc

    # 3. Evidence adequacy check
    if not entity_record.evidence_chain and entity_record.primary_role_evidence is None and entity_record.referenced_role_evidence is None:
        disc = DocumentDiscrepancy(
            discrepancy_id=f"disc_missing_evidence_{contract_requirement_id}",
            category=DiscrepancyCategory.MISSING_EVIDENCE,
            severity=Severity.MAJOR,
            reason_code="INSUFFICIENT_ROLE_EVIDENCE",
            description=(
                f"Contractual requirement '{contract_requirement_id}' requires entity '{required_entity_name}' "
                f"in role '{required_role.value}', but evidence is missing or insufficient."
            ),
            source_document_id=entity_record.primary_document_id,
            conflicting_document_id=entity_record.referenced_document_id,
            applicable_requirement_id=contract_requirement_id,
            applicable_entity_role=required_role,
            applicable_coverage_type=coverage_type,
            evidence_chain=(),
            requires_human_review=True,
        )
        return False, disc

    # 4. Check if role is satisfied across BOTH primary and referenced documents WITH affirmative role evidence
    primary_has_role = (
        is_p_match
        and entity_record.primary_entity_role == required_role
    )
    primary_role_evidenced = (
        primary_has_role
        and _has_role_evidence(required_role, entity_record.primary_document_id, entity_record, entity_record.primary_role_evidence)
    )

    referenced_has_role = (
        (is_r_match or entity_record.is_confirmed_match)
        and entity_record.referenced_entity_role == required_role
    )
    referenced_role_evidenced = (
        referenced_has_role
        and _has_role_evidence(required_role, entity_record.referenced_document_id, entity_record, entity_record.referenced_role_evidence)
    )

    if primary_role_evidenced or referenced_role_evidenced:
        return True, None

    # If the role was claimed/asserted on either document, but affirmative role evidence is missing
    if primary_has_role or referenced_has_role:
        disc = DocumentDiscrepancy(
            discrepancy_id=f"disc_missing_role_evidence_{contract_requirement_id}",
            category=DiscrepancyCategory.MISSING_EVIDENCE,
            severity=Severity.MAJOR,
            reason_code="MISSING_ROLE_EVIDENCE",
            description=(
                f"Entity '{entity_record.primary_entity_name}' identity is matched, but affirmative evidence "
                f"proving the required contractual role '{required_role.value}' is missing."
            ),
            source_document_id=entity_record.primary_document_id,
            conflicting_document_id=entity_record.referenced_document_id,
            applicable_requirement_id=contract_requirement_id,
            applicable_entity_role=required_role,
            applicable_coverage_type=coverage_type,
            evidence_chain=(),
            requires_human_review=True,
        )
        return False, disc

    # 5. Role is NOT satisfied in either document
    # Same entity with no evidence of the required role -> unresolved (MISSING_EVIDENCE), not confirmed violation
    if entity_record.is_confirmed_match:
        disc = DocumentDiscrepancy(
            discrepancy_id=f"disc_missing_role_{contract_requirement_id}",
            category=DiscrepancyCategory.MISSING_EVIDENCE,
            severity=Severity.MAJOR,
            reason_code="INSUFFICIENT_ROLE_EVIDENCE",
            description=(
                f"Entity '{entity_record.primary_entity_name}' is confirmed, but neither document "
                f"evidences required contractual role '{required_role.value}' for {contract_requirement_id}."
            ),
            source_document_id=entity_record.primary_document_id,
            conflicting_document_id=entity_record.referenced_document_id,
            applicable_requirement_id=contract_requirement_id,
            applicable_entity_role=required_role,
            applicable_coverage_type=coverage_type,
            evidence_chain=(),
            requires_human_review=True,
        )
        return False, disc

    # Corporate suffix discrepancy -> Document Discrepancy
    if entity_record.classification == EntityMatchClassification.LEGAL_SUFFIX_DISCREPANCY:
        disc = DocumentDiscrepancy(
            discrepancy_id=f"disc_suffix_{contract_requirement_id}",
            category=DiscrepancyCategory.DOCUMENT_DISCREPANCY,
            severity=Severity.MAJOR,
            reason_code="CORPORATE_SUFFIX_DISCREPANCY",
            description=(
                f"Corporate suffix discrepancy between '{entity_record.primary_entity_name}' and "
                f"required entity '{required_entity_name}' for requirement '{contract_requirement_id}'."
            ),
            source_document_id=entity_record.primary_document_id,
            conflicting_document_id=entity_record.referenced_document_id,
            applicable_requirement_id=contract_requirement_id,
            applicable_entity_role=required_role,
            applicable_coverage_type=coverage_type,
            evidence_chain=entity_record.evidence_chain,
            requires_human_review=True,
        )
        return False, disc

    # Unresolved entity relationship -> Ambiguous relationship
    disc = DocumentDiscrepancy(
        discrepancy_id=f"disc_ambiguous_{contract_requirement_id}",
        category=DiscrepancyCategory.AMBIGUOUS_RELATIONSHIP,
        severity=Severity.MAJOR,
        reason_code=entity_record.review_reason_code or "AMBIGUOUS_ENTITY_RELATIONSHIP",
        description=(
            f"Unresolved entity relationship ({entity_record.classification.value}) for "
            f"'{entity_record.primary_entity_name}' against required '{required_entity_name}'."
        ),
        source_document_id=entity_record.primary_document_id,
        conflicting_document_id=entity_record.referenced_document_id,
        applicable_requirement_id=contract_requirement_id,
        applicable_entity_role=required_role,
        applicable_coverage_type=coverage_type,
        evidence_chain=entity_record.evidence_chain,
        requires_human_review=True,
    )
    return False, disc


# =============================================================================
# 4. Temporal Date Reconciliation
# =============================================================================

def reconcile_dates(
    policy_effective_date: Optional[date],
    policy_expiration_date: Optional[date],
    policy_date_evidence: Tuple[EvidenceReference, ...],
    endorsement_effective_date: Optional[date],
    endorsement_expiration_date: Optional[date],
    endorsement_date_evidence: Tuple[EvidenceReference, ...],
    evaluation_date: Optional[date] = None,
    policy_document_id: Optional[str] = None,
    endorsement_document_id: Optional[str] = None,
    evidence_chain: Tuple[EvidenceReference, ...] = (),
    contractual_duration_requirement_id: Optional[str] = None,
    required_coverage_end_date: Optional[date] = None,
    requires_coverage_through_policy_expiration: bool = False,
    is_duration_requirement_validated: bool = False,
) -> DateReconciliationRecord:
    """Deterministically reconcile policy and endorsement validity periods.
    
    Guarantees (Correction A):
    - Missing material date information must not silently produce requires_human_review=False.
    - Explicit unresolved handling for:
      * Missing policy effective or expiration dates when policy activity must be evaluated.
      * Missing endorsement effective or expiration dates when endorsement activity must be evaluated.
      * Missing evaluation date when an active/inactive conclusion is required.
      * Missing or inadequate date evidence for populated dates.
      * Incomplete validated contractual duration requirements.
    - Do not classify missing information as a confirmed contractual violation.
    - Do not infer noncompliance merely because an endorsement expires before the underlying policy
      when it remains active on the evaluation date and no validated contractual duration requirement
      establishes that longer coverage is required.
    - Inverted dates trigger immediate ValueError.
    """
    # Track whether policy or endorsement evaluation is required
    evaluating_policy = bool(
        policy_document_id is not None
        or policy_effective_date is not None
        or policy_expiration_date is not None
        or policy_date_evidence
    )
    evaluating_endorsement = bool(
        endorsement_document_id is not None
        or endorsement_effective_date is not None
        or endorsement_expiration_date is not None
        or endorsement_date_evidence
    )

    is_policy_active: Optional[bool] = None
    is_endorsement_active: Optional[bool] = None

    missing_eval_date = (evaluation_date is None) and (evaluating_policy or evaluating_endorsement)
    missing_policy_dates = evaluating_policy and (policy_effective_date is None or policy_expiration_date is None)
    missing_endorsement_dates = evaluating_endorsement and (endorsement_effective_date is None or endorsement_expiration_date is None)

    if evaluation_date is not None:
        if policy_effective_date is not None and policy_expiration_date is not None:
            if policy_effective_date <= evaluation_date <= policy_expiration_date:
                is_policy_active = True
            else:
                is_policy_active = False

        if endorsement_effective_date is not None and endorsement_expiration_date is not None:
            if endorsement_effective_date <= evaluation_date <= endorsement_expiration_date:
                is_endorsement_active = True
            else:
                is_endorsement_active = False

    # Midterm addition
    is_midterm: Optional[bool] = None
    if endorsement_effective_date is not None and policy_effective_date is not None:
        is_midterm = endorsement_effective_date > policy_effective_date

    # Premature expiration relative to underlying policy
    is_premature: Optional[bool] = None
    if endorsement_expiration_date is not None and policy_expiration_date is not None:
        if endorsement_expiration_date < policy_expiration_date:
            if is_endorsement_active is not None:
                is_premature = True
        else:
            is_premature = False

    # Review & Discrepancy Derivation (Correction A):
    requires_review = False
    discrepancy_cat: Optional[DiscrepancyCategory] = None
    reason_code: Optional[str] = None

    if missing_eval_date:
        requires_review = True
        discrepancy_cat = DiscrepancyCategory.MISSING_EVIDENCE
        reason_code = "MISSING_EVALUATION_DATE"
    elif missing_policy_dates:
        requires_review = True
        discrepancy_cat = DiscrepancyCategory.MISSING_EVIDENCE
        reason_code = "MISSING_POLICY_DATES"
    elif missing_endorsement_dates:
        requires_review = True
        discrepancy_cat = DiscrepancyCategory.MISSING_EVIDENCE
        reason_code = "MISSING_ENDORSEMENT_DATES"
    elif is_policy_active is False:
        requires_review = True
        discrepancy_cat = DiscrepancyCategory.DOCUMENT_DISCREPANCY
        reason_code = "POLICY_INACTIVE_ON_EVALUATION_DATE"
    elif is_endorsement_active is False:
        requires_review = True
        discrepancy_cat = DiscrepancyCategory.DOCUMENT_DISCREPANCY
        reason_code = "ENDORSEMENT_INACTIVE_ON_EVALUATION_DATE"
    elif contractual_duration_requirement_id is not None:
        if not is_duration_requirement_validated:
            requires_review = True
            discrepancy_cat = DiscrepancyCategory.DOCUMENT_DISCREPANCY
            reason_code = "UNVALIDATED_DURATION_REQUIREMENT"
        elif required_coverage_end_date is None and not requires_coverage_through_policy_expiration:
            # Incomplete validated contractual duration requirements
            requires_review = True
            discrepancy_cat = DiscrepancyCategory.DOCUMENT_DISCREPANCY
            reason_code = "INCOMPLETE_DURATION_REQUIREMENT_TERMS"
        else:
            violation = False
            if requires_coverage_through_policy_expiration and is_premature is True:
                violation = True
            elif required_coverage_end_date is not None and endorsement_expiration_date is not None:
                if endorsement_expiration_date < required_coverage_end_date:
                    violation = True

            if violation:
                requires_review = True
                discrepancy_cat = DiscrepancyCategory.CONFIRMED_CONTRACTUAL_VIOLATION
                reason_code = "PREMATURE_EXPIRATION_VIOLATION"
            else:
                requires_review = False
                discrepancy_cat = None
                reason_code = None
    else:
        # Earlier endorsement expiration alone does not create a confirmed violation
        requires_review = False
        discrepancy_cat = None
        reason_code = None

    return DateReconciliationRecord(
        policy_document_id=policy_document_id,
        policy_effective_date=policy_effective_date,
        policy_expiration_date=policy_expiration_date,
        policy_date_evidence=policy_date_evidence,
        endorsement_document_id=endorsement_document_id,
        endorsement_effective_date=endorsement_effective_date,
        endorsement_expiration_date=endorsement_expiration_date,
        endorsement_date_evidence=endorsement_date_evidence,
        evaluation_date=evaluation_date,
        is_midterm_addition=is_midterm,
        is_policy_active_on_evaluation_date=is_policy_active,
        is_endorsement_active_on_evaluation_date=is_endorsement_active,
        is_premature_expiration=is_premature,
        requires_human_review=requires_review,
        discrepancy_category=discrepancy_cat,
        review_reason_code=reason_code,
        evidence_chain=evidence_chain,
    )


# =============================================================================
# 5. Relationship Classification with Relationship-Specific Evidence
# =============================================================================

def classify_document_relationship(
    edge_id: str,
    source_document_id: str,
    target_document_id: Optional[str],
    relationship_type: DocumentRelationshipType,
    classification: EdgeClassification,
    is_compliance_relevant: bool = True,
    evidence_references: Tuple[EvidenceReference, ...] = (),
    associated_policy_id: Optional[str] = None,
    coverage_type: Optional[CoverageType] = None,
    has_relationship_evidence: bool = True,
    requires_human_review: Optional[bool] = None,
    review_reason_code: Optional[str] = None,
) -> DocumentRelationshipEdge:
    """Build a validated directional relationship edge between documents.
    
    Guarantees (Correction B):
    - Do not confirm relationships merely because generic keywords occur somewhere in combined evidence text.
    - Evidence must be tied to the relevant source and target documents.
    - Require evidence that actually supports that particular relationship:
      * SAME_POLICY: policy/coverage evidence in both source and target.
      * ENDORSEMENT_TO_POLICY: endorsement language in source, policy/coverage in target.
      * DECLARATION_FOR_POLICY: declaration language in source, policy/coverage in target.
      * REPLACES_DOCUMENT: affirmative supersession evidence in source, target document in target.
      * AMENDS_DOCUMENT: affirmative amendment evidence in source, target document in target.
      * DUPLICATE_OF: explicit duplicate/hash evidence.
    - If evidence is insufficient, return an unresolved/ambiguous relationship requiring human review.
    """
    if relationship_type == DocumentRelationshipType.ORPHAN_DOCUMENT:
        return DocumentRelationshipEdge(
            edge_id=edge_id,
            source_document_id=source_document_id,
            target_document_id=None,
            relationship_type=DocumentRelationshipType.ORPHAN_DOCUMENT,
            classification=EdgeClassification.UNLINKED_ORPHAN,
            is_compliance_relevant=is_compliance_relevant,
            evidence_references=evidence_references,
            is_confirmed=False,
            requires_human_review=True,
            review_reason_code=review_reason_code or "ORPHAN_DOCUMENT_NO_POLICY_LINK",
        )

    # Validate relationship-specific affirmative evidence across both documents
    doc_ids = {ref.document_id for ref in evidence_references}
    has_both_docs = bool(source_document_id in doc_ids and target_document_id is not None and target_document_id in doc_ids)

    src_text = " ".join((ref.source_text or "") for ref in evidence_references if ref.document_id == source_document_id)
    tgt_text = " ".join((ref.source_text or "") for ref in evidence_references if ref.document_id == target_document_id)

    has_specific_evidence = False

    if has_both_docs and has_relationship_evidence:
        if relationship_type == DocumentRelationshipType.REPLACES_DOCUMENT:
            has_specific_evidence = bool(REPLACES_EVIDENCE_PATTERN.search(src_text))

        elif relationship_type == DocumentRelationshipType.AMENDS_DOCUMENT:
            has_specific_evidence = bool(AMENDS_EVIDENCE_PATTERN.search(src_text))

        elif relationship_type == DocumentRelationshipType.DUPLICATE_OF:
            has_specific_evidence = bool(DUPLICATE_EVIDENCE_PATTERN.search(f"{src_text} {tgt_text}"))

        elif relationship_type == DocumentRelationshipType.DECLARATION_FOR_POLICY:
            has_specific_evidence = bool(
                DECLARATION_EVIDENCE_PATTERN.search(src_text)
                and POLICY_COVERAGE_EVIDENCE_PATTERN.search(tgt_text)
            )

        elif relationship_type == DocumentRelationshipType.ENDORSEMENT_TO_POLICY:
            has_specific_evidence = bool(
                ENDORSEMENT_EVIDENCE_PATTERN.search(src_text)
                and POLICY_COVERAGE_EVIDENCE_PATTERN.search(tgt_text)
            )

        elif relationship_type == DocumentRelationshipType.SAME_POLICY:
            has_specific_evidence = bool(
                POLICY_COVERAGE_EVIDENCE_PATTERN.search(src_text)
                and POLICY_COVERAGE_EVIDENCE_PATTERN.search(tgt_text)
            )
        else:
            has_specific_evidence = True

    # If classification is confirmed but relationship-specific evidence is missing, downgrade to AMBIGUOUS
    wants_confirmed = classification in (
        EdgeClassification.CONFIRMED_EXACT,
        EdgeClassification.CONFIRMED_NORMALIZED,
        EdgeClassification.CONFIRMED_DBA,
    )

    if wants_confirmed and not has_specific_evidence:
        default_reason = "UNSUPPORTED_RELATIONSHIP_ASSERTION" if not has_relationship_evidence else "INSUFFICIENT_RELATIONSHIP_EVIDENCE"
        return DocumentRelationshipEdge(
            edge_id=edge_id,
            source_document_id=source_document_id,
            target_document_id=target_document_id,
            relationship_type=relationship_type,
            associated_policy_id=associated_policy_id,
            coverage_type=coverage_type,
            classification=EdgeClassification.AMBIGUOUS,
            is_compliance_relevant=is_compliance_relevant,
            evidence_references=evidence_references,
            is_confirmed=False,
            requires_human_review=True,
            review_reason_code=review_reason_code or default_reason,
        )

    is_confirmed = wants_confirmed and has_specific_evidence
    if requires_human_review is None:
        requires_human_review = not is_confirmed

    return DocumentRelationshipEdge(
        edge_id=edge_id,
        source_document_id=source_document_id,
        target_document_id=target_document_id,
        relationship_type=relationship_type,
        associated_policy_id=associated_policy_id,
        coverage_type=coverage_type,
        classification=classification,
        is_compliance_relevant=is_compliance_relevant,
        evidence_references=evidence_references,
        is_confirmed=is_confirmed,
        requires_human_review=requires_human_review,
        review_reason_code=review_reason_code,
    )


# =============================================================================
# 6. Deterministic Reconciliation Engine
# =============================================================================

class DeterministicReconciliationEngine:
    """Deterministic, rule-based cross-document reconciliation engine.
    
    Operates without AI in the decision path: takes extracted documents,
    packet manifest, and contractual requirements to build a fully validated,
    immutable CrossDocumentReconciliationResult.
    """

    def reconcile_packet(
        self,
        document_packet_id: str,
        packet_manifest: Tuple[DocumentManifestEntry, ...],
        primary_coi_id: Optional[str] = None,
        graph_edges: Tuple[DocumentRelationshipEdge, ...] = (),
        entity_records: Tuple[EntityReconciliationRecord, ...] = (),
        policy_records: Tuple[PolicyReconciliationRecord, ...] = (),
        date_records: Tuple[DateReconciliationRecord, ...] = (),
        missing_evidence_records: Tuple[MissingEvidenceProvenance, ...] = (),
        discrepancies: Tuple[DocumentDiscrepancy, ...] = (),
    ) -> CrossDocumentReconciliationResult:
        """Construct and validate complete immutable reconciliation result."""
        return CrossDocumentReconciliationResult(
            document_packet_id=document_packet_id,
            primary_coi_id=primary_coi_id,
            packet_manifest=packet_manifest,
            graph_edges=graph_edges,
            entity_records=entity_records,
            policy_records=policy_records,
            date_records=date_records,
            missing_evidence_records=missing_evidence_records,
            discrepancies=discrepancies,
        )


__all__ = [
    "reconcile_policy_identifiers",
    "reconcile_entity_identities",
    "check_contractual_role_satisfaction",
    "reconcile_dates",
    "classify_document_relationship",
    "DeterministicReconciliationEngine",
]
