"""Unit tests for Milestone 3.5C Deterministic Cross-Document Reconciliation Logic.

Explicitly validates required scenarios C-01 through C-14:
- C-01: Same legal entity is NAMED_INSURED on COI and ADDITIONAL_INSURED on endorsement -> Identity remains EXACT; roles evaluated separately
- C-02: Same legal entity has different document roles -> Role difference does not establish different legal identity
- C-03: Same identity, but required contractual role is not evidenced -> Requirement remains unsatisfied or unresolved
- C-04: Role mismatch without a validated contractual requirement -> Must not create confirmed violation
- C-05: Two genuinely different legal entities -> Identity and roles evaluated independently
- C-06: Permitted formatting differences in policy identifiers -> FORMATTING_NORMALIZED
- C-07: Meaningful policy suffix differences -> Must not become EXACT
- C-08: Leading-zero differences -> Must follow explicitly documented normalization rules
- C-09: Endorsement expires earlier but remains active on evaluation date -> No automatic confirmed violation
- C-10: Endorsement expired before evaluation date with complete evidence -> Inactive conclusion supported by evidence
- C-11: Evaluation date missing -> No active/inactive conclusion
- C-12: Matching policy identifiers without relationship-specific evidence -> Relationship not confirmed
- C-13: Replacement asserted without supersession evidence -> Replacement not confirmed
- C-14: Zero compliance-relevant edges -> Must not establish compliance
"""
from __future__ import annotations

import unittest
from datetime import date

from app.compliance.reconciliation import (
    DeterministicReconciliationEngine,
    check_contractual_role_satisfaction,
    classify_document_relationship,
    reconcile_dates,
    reconcile_entity_identities,
    reconcile_policy_identifiers,
)
from app.schemas.insurance import (
    BoundingBox,
    CoverageType,
    DocumentType,
    EvidenceReference,
    Severity,
)
from app.schemas.reconciliation import (
    CrossDocumentReconciliationResult,
    DateReconciliationRecord,
    DiscrepancyCategory,
    DocumentDiscrepancy,
    DocumentManifestEntry,
    DocumentRelationshipEdge,
    DocumentRelationshipType,
    EdgeClassification,
    EntityMatchClassification,
    EntityReconciliationRecord,
    EntityRole,
    GraphEvaluationStatus,
    PolicyMatchClassification,
    PolicyReconciliationRecord,
    normalize_policy_identifier,
)


class TestReconciliationLogic(unittest.TestCase):
    """Test suite for deterministic reconciliation algorithms and invariants."""

    def setUp(self):
        self.doc_coi_manifest = DocumentManifestEntry(
            document_id="doc_coi",
            file_name="coi.pdf",
            sha256_hash="a" * 64,
            page_count=2,
            detected_document_type=DocumentType.COI,
        )
        self.doc_end_manifest = DocumentManifestEntry(
            document_id="doc_end",
            file_name="endorsement.pdf",
            sha256_hash="b" * 64,
            page_count=3,
            detected_document_type=DocumentType.ENDORSEMENT,
        )
        self.doc_dec_manifest = DocumentManifestEntry(
            document_id="doc_dec",
            file_name="dec_page.pdf",
            sha256_hash="c" * 64,
            page_count=5,
            detected_document_type=DocumentType.POLICY_DEC_PAGE,
        )

        self.ref_coi = EvidenceReference(
            document_id="doc_coi",
            document_type=DocumentType.COI,
            page_number=1,
            source_text="Apex Electrical LLC",
            bounding_box=BoundingBox(x=0.1, y=0.1, width=0.3, height=0.05),
        )
        self.ref_end = EvidenceReference(
            document_id="doc_end",
            document_type=DocumentType.ENDORSEMENT,
            page_number=1,
            source_text="Apex Electrical LLC",
            bounding_box=BoundingBox(x=0.1, y=0.1, width=0.3, height=0.05),
        )
        self.ref_dec = EvidenceReference(
            document_id="doc_dec",
            document_type=DocumentType.POLICY_DEC_PAGE,
            page_number=1,
            source_text="Apex Electrical LLC",
            bounding_box=BoundingBox(x=0.1, y=0.1, width=0.3, height=0.05),
        )

    # =========================================================================
    # C-01 & C-02: Separate Legal Identity from Document Roles
    # =========================================================================

    def test_c01_same_legal_entity_different_roles_exact_match(self):
        """C-01: Same legal entity is NAMED_INSURED on COI and ADDITIONAL_INSURED on endorsement.
        
        Identity remains EXACT; roles are evaluated separately.
        """
        rec = reconcile_entity_identities(
            primary_entity_name="Apex Electrical LLC",
            primary_entity_role=EntityRole.NAMED_INSURED,
            primary_document_id="doc_coi",
            referenced_entity_name="Apex Electrical LLC",
            referenced_entity_role=EntityRole.ADDITIONAL_INSURED,
            referenced_document_id="doc_end",
            evidence_chain=(self.ref_coi, self.ref_end),
        )
        self.assertEqual(rec.classification, EntityMatchClassification.EXACT)
        self.assertTrue(rec.is_confirmed_match)
        self.assertFalse(rec.requires_human_review)
        self.assertEqual(rec.primary_entity_role, EntityRole.NAMED_INSURED)
        self.assertEqual(rec.referenced_entity_role, EntityRole.ADDITIONAL_INSURED)

    def test_c02_different_document_roles_does_not_establish_distinct_identity(self):
        """C-02: Role difference does not establish different legal identity."""
        rec = reconcile_entity_identities(
            primary_entity_name="Zenith Mechanical Inc",
            primary_entity_role=EntityRole.NAMED_INSURED,
            primary_document_id="doc_coi",
            referenced_entity_name="Zenith Mechanical Inc",
            referenced_entity_role=EntityRole.CERTIFICATE_HOLDER,
            referenced_document_id="doc_end",
            evidence_chain=(self.ref_coi, self.ref_end),
        )
        # Identity is EXACT, never DISTINCT_LEGAL_ENTITY solely because roles differ
        self.assertEqual(rec.classification, EntityMatchClassification.EXACT)
        self.assertTrue(rec.is_confirmed_match)
        self.assertFalse(rec.requires_human_review)

    # =========================================================================
    # C-03 & C-04: Contractual Role Satisfaction & Violation Guards
    # =========================================================================

    def test_c03_same_identity_unsupported_role_evidence_unresolved(self):
        """C-03: Same identity, but required contractual role is not evidenced -> unresolved."""
        rec = EntityReconciliationRecord(
            primary_entity_name="Apex Electrical LLC",
            primary_entity_role=EntityRole.NAMED_INSURED,
            primary_document_id="doc_coi",
            referenced_entity_name="Apex Electrical LLC",
            referenced_entity_role=EntityRole.NAMED_INSURED,
            referenced_document_id="doc_end",
            classification=EntityMatchClassification.AMBIGUOUS_IDENTITY,
            is_confirmed_match=False,
            requires_human_review=True,
            evidence_chain=(),  # Evidence missing!
        )
        satisfied, disc = check_contractual_role_satisfaction(
            entity_record=rec,
            required_entity_name="Apex Electrical LLC",
            required_role=EntityRole.NAMED_INSURED,
            contract_requirement_id="REQ_NAMED_INSURED",
        )
        self.assertFalse(satisfied)
        self.assertIsNotNone(disc)
        assert disc is not None
        # Must be MISSING_EVIDENCE requiring human review, NOT a confirmed violation!
        self.assertEqual(disc.category, DiscrepancyCategory.MISSING_EVIDENCE)
        self.assertEqual(disc.reason_code, "INSUFFICIENT_ROLE_EVIDENCE")
        self.assertTrue(disc.requires_human_review)

    def test_c04_role_mismatch_without_validated_requirement_creates_no_violation(self):
        """C-04: Role mismatch without a validated contractual requirement must not create confirmed violation."""
        rec = EntityReconciliationRecord(
            primary_entity_name="Apex Electrical LLC",
            primary_entity_role=EntityRole.CERTIFICATE_HOLDER,
            primary_document_id="doc_coi",
            referenced_entity_name="Apex Electrical LLC",
            referenced_entity_role=EntityRole.ADDITIONAL_INSURED,
            referenced_document_id="doc_end",
            classification=EntityMatchClassification.EXACT,
            is_confirmed_match=True,
            requires_human_review=False,
            evidence_chain=(self.ref_coi, self.ref_end),
        )
        # Missing contract requirement ID
        satisfied, disc = check_contractual_role_satisfaction(
            entity_record=rec,
            required_entity_name="Apex Electrical LLC",
            required_role=EntityRole.NAMED_INSURED,
            contract_requirement_id=None,  # No validated requirement!
        )
        self.assertFalse(satisfied)
        # Must NOT create a confirmed contractual violation!
        self.assertIsNone(disc)

    def test_c05_genuinely_different_legal_entities(self):
        """C-05: Two genuinely different legal entities evaluated independently of roles."""
        rec = reconcile_entity_identities(
            primary_entity_name="Apex Electrical LLC",
            primary_entity_role=EntityRole.NAMED_INSURED,
            primary_document_id="doc_coi",
            referenced_entity_name="Zenith Plumbing Inc",
            referenced_entity_role=EntityRole.NAMED_INSURED,
            referenced_document_id="doc_end",
            evidence_chain=(self.ref_coi, self.ref_end),
        )
        self.assertEqual(rec.classification, EntityMatchClassification.DISTINCT_LEGAL_ENTITY)
        self.assertFalse(rec.is_confirmed_match)
        self.assertTrue(rec.requires_human_review)
        self.assertEqual(rec.review_reason_code, "DISTINCT_LEGAL_ENTITIES")

    # =========================================================================
    # C-06, C-07, C-08: Policy Identifier Normalization Rules
    # =========================================================================

    def test_c06_permitted_formatting_differences_policy_identifiers(self):
        """C-06: Permitted formatting differences (spaces, hyphens, slashes, periods) -> FORMATTING_NORMALIZED."""
        # Spaces, hyphens, slashes, periods
        rec = reconcile_policy_identifiers(
            coi_document_id="doc_coi",
            coi_policy_number="GL-12345/A.01",
            coi_evidence=self.ref_coi,
            endorsement_document_id="doc_end",
            endorsement_policy_number="GL 12345-A 01",  # Same chars, different delimiters
            endorsement_evidence=self.ref_end,
        )
        self.assertEqual(rec.classification, PolicyMatchClassification.FORMATTING_NORMALIZED)
        self.assertTrue(rec.is_confirmed_match)
        self.assertFalse(rec.requires_human_review)

    def test_c07_meaningful_policy_suffix_differences_never_exact(self):
        """C-07: Meaningful policy renewal suffix differences must NOT become EXACT."""
        rec = reconcile_policy_identifiers(
            coi_document_id="doc_coi",
            coi_policy_number="GL-9876543-01",
            coi_evidence=self.ref_coi,
            endorsement_document_id="doc_end",
            endorsement_policy_number="GL-9876543-02",  # Renewal suffix -01 vs -02
            endorsement_evidence=self.ref_end,
        )
        self.assertNotEqual(rec.classification, PolicyMatchClassification.EXACT)
        self.assertNotEqual(rec.classification, PolicyMatchClassification.FORMATTING_NORMALIZED)
        self.assertEqual(rec.classification, PolicyMatchClassification.POSSIBLE_FAMILY)
        self.assertFalse(rec.is_confirmed_match)
        self.assertTrue(rec.requires_human_review)

    def test_c08_leading_zero_differences_in_policy_identifiers(self):
        """C-08: Leading zeros are preserved and must not be silently stripped to equate numbers."""
        norm_zero = normalize_policy_identifier("0012345")
        norm_no_zero = normalize_policy_identifier("12345")
        self.assertEqual(norm_zero, "0012345")
        self.assertEqual(norm_no_zero, "12345")
        self.assertNotEqual(norm_zero, norm_no_zero)

        rec = reconcile_policy_identifiers(
            coi_document_id="doc_coi",
            coi_policy_number="0012345",
            coi_evidence=self.ref_coi,
            endorsement_document_id="doc_end",
            endorsement_policy_number="12345",
            endorsement_evidence=self.ref_end,
        )
        # Leading zero difference without supporting family evidence classifies as CONFLICTING, NEVER EXACT or NORMALIZED
        self.assertNotEqual(rec.classification, PolicyMatchClassification.EXACT)
        self.assertNotEqual(rec.classification, PolicyMatchClassification.FORMATTING_NORMALIZED)
        self.assertEqual(rec.classification, PolicyMatchClassification.CONFLICTING)
        self.assertFalse(rec.is_confirmed_match)
        self.assertTrue(rec.requires_human_review)

    # =========================================================================
    # C-09, C-10, C-11: Date Reconciliation
    # =========================================================================

    def test_c09_endorsement_expires_earlier_but_active_on_eval_date(self):
        """C-09: Endorsement expiring earlier but remaining active on evaluation date is NOT noncompliant."""
        rec = reconcile_dates(
            policy_document_id="doc_coi",
            policy_effective_date=date(2025, 1, 1),
            policy_expiration_date=date(2026, 1, 1),
            policy_date_evidence=(self.ref_coi,),
            endorsement_document_id="doc_end",
            endorsement_effective_date=date(2025, 1, 1),
            endorsement_expiration_date=date(2025, 10, 1),  # Expires before policy!
            endorsement_date_evidence=(self.ref_end,),
            evaluation_date=date(2025, 6, 1),  # But ACTIVE on evaluation date!
            evidence_chain=(self.ref_coi, self.ref_end),
        )
        self.assertTrue(rec.is_policy_active_on_evaluation_date)
        self.assertTrue(rec.is_endorsement_active_on_evaluation_date)
        self.assertTrue(rec.is_premature_expiration)
        # Must NOT automatically trigger review or noncompliance on the evaluation date!
        self.assertFalse(rec.requires_human_review)
        self.assertIsNone(rec.discrepancy_category)

    def test_c10_endorsement_expired_before_evaluation_date_with_evidence(self):
        """C-10: Endorsement expired before evaluation date with complete evidence -> inactive conclusion."""
        rec = reconcile_dates(
            policy_document_id="doc_coi",
            policy_effective_date=date(2025, 1, 1),
            policy_expiration_date=date(2026, 1, 1),
            policy_date_evidence=(self.ref_coi,),
            endorsement_document_id="doc_end",
            endorsement_effective_date=date(2025, 1, 1),
            endorsement_expiration_date=date(2025, 5, 1),  # Expired before evaluation date!
            endorsement_date_evidence=(self.ref_end,),
            evaluation_date=date(2025, 6, 1),
            evidence_chain=(self.ref_coi, self.ref_end),
        )
        self.assertTrue(rec.is_policy_active_on_evaluation_date)
        self.assertFalse(rec.is_endorsement_active_on_evaluation_date)
        self.assertTrue(rec.requires_human_review)
        self.assertEqual(rec.discrepancy_category, DiscrepancyCategory.DOCUMENT_DISCREPANCY)
        self.assertEqual(rec.review_reason_code, "ENDORSEMENT_INACTIVE_ON_EVALUATION_DATE")

    def test_c11_evaluation_date_missing_no_active_inactive_conclusion(self):
        """C-11: Missing evaluation date leaves active/inactive conclusions as None."""
        rec = reconcile_dates(
            policy_document_id="doc_coi",
            policy_effective_date=date(2025, 1, 1),
            policy_expiration_date=date(2026, 1, 1),
            policy_date_evidence=(self.ref_coi,),
            endorsement_document_id="doc_end",
            endorsement_effective_date=date(2025, 1, 1),
            endorsement_expiration_date=date(2026, 1, 1),
            endorsement_date_evidence=(self.ref_end,),
            evaluation_date=None,  # Missing!
            evidence_chain=(self.ref_coi, self.ref_end),
        )
        self.assertIsNone(rec.evaluation_date)
        self.assertIsNone(rec.is_policy_active_on_evaluation_date)
        self.assertIsNone(rec.is_endorsement_active_on_evaluation_date)

    # =========================================================================
    # C-12, C-13: Document Relationship Evidence Invariants
    # =========================================================================

    def test_c12_matching_policy_identifiers_without_relationship_evidence(self):
        """C-12: Matching policy number without relationship evidence does not confirm edge."""
        edge = classify_document_relationship(
            edge_id="e_unsupported",
            source_document_id="doc_coi",
            target_document_id="doc_end",
            relationship_type=DocumentRelationshipType.SAME_POLICY,
            classification=EdgeClassification.AMBIGUOUS,
            evidence_references=(),  # No evidence!
        )
        self.assertFalse(edge.is_confirmed)
        self.assertTrue(edge.requires_human_review)

    def test_c13_replacement_asserted_without_supersession_evidence(self):
        """C-13: Replacement asserted without supersession evidence must NOT be confirmed."""
        edge = classify_document_relationship(
            edge_id="e_replace",
            source_document_id="doc_coi",
            target_document_id="doc_end",
            relationship_type=DocumentRelationshipType.REPLACES_DOCUMENT,
            classification=EdgeClassification.CONFIRMED_EXACT,
            has_relationship_evidence=False,  # No supersession evidence!
            evidence_references=(self.ref_coi, self.ref_end),
        )
        # Even with matching policy references, lack of replacement evidence prevents confirmation
        self.assertFalse(edge.is_confirmed)
        self.assertTrue(edge.requires_human_review)
        self.assertEqual(edge.classification, EdgeClassification.AMBIGUOUS)
        self.assertEqual(edge.review_reason_code, "UNSUPPORTED_RELATIONSHIP_ASSERTION")

    # =========================================================================
    # C-14: Zero Compliance-Relevant Edges
    # =========================================================================

    def test_c14_zero_compliance_relevant_edges_never_confirms_compliance(self):
        """C-14: Zero compliance-relevant edges must explicitly result in all_relationships_confirmed=False."""
        engine = DeterministicReconciliationEngine()

        info_edge = classify_document_relationship(
            edge_id="e_info",
            source_document_id="doc_coi",
            target_document_id="doc_end",
            relationship_type=DocumentRelationshipType.UNRELATED,
            classification=EdgeClassification.AMBIGUOUS,
            is_compliance_relevant=False,  # Non-compliance relevant
            requires_human_review=True,
        )

        result = engine.reconcile_packet(
            document_packet_id="packet_empty_graph",
            packet_manifest=(self.doc_coi_manifest, self.doc_end_manifest),
            graph_edges=(info_edge,),
        )
        # Must not prove compliance
        self.assertFalse(result.all_relationships_confirmed)
        # And must not fabricate unresolved contradictions from informational edges
        self.assertFalse(result.has_unresolved_contradictions)

    # =========================================================================
    # Correction 1: Contractual Role Satisfaction (C-15 to C-19)
    # =========================================================================

    def test_c15_coi_named_insured_endorsement_additional_insured_satisfies_ai_requirement(self):
        """C-15: Primary role is NAMED_INSURED on COI, referenced role is ADDITIONAL_INSURED on endorsement -> satisfies AI requirement."""
        ent_record = reconcile_entity_identities(
            primary_entity_name="Apex Electrical LLC",
            primary_entity_role=EntityRole.NAMED_INSURED,
            primary_document_id="doc_coi",
            referenced_entity_name="Apex Electrical LLC",
            referenced_entity_role=EntityRole.ADDITIONAL_INSURED,
            referenced_document_id="doc_end",
            evidence_chain=(self.ref_coi, self.ref_end),
        )
        self.assertTrue(ent_record.is_confirmed_match)

        is_satisfied, disc = check_contractual_role_satisfaction(
            entity_record=ent_record,
            required_entity_name="Apex Electrical LLC",
            required_role=EntityRole.ADDITIONAL_INSURED,
            contract_requirement_id="REQ_AI_01",
            coverage_type=CoverageType.GENERAL_LIABILITY,
            is_requirement_validated=True,
        )
        self.assertTrue(is_satisfied)
        self.assertIsNone(disc)

    def test_c16_same_entity_no_evidence_of_required_role_unresolved(self):
        """C-16: Same entity with no evidence of the required role -> unresolved (MISSING_EVIDENCE), not confirmed violation."""
        ent_record = reconcile_entity_identities(
            primary_entity_name="Apex Electrical LLC",
            primary_entity_role=EntityRole.NAMED_INSURED,
            primary_document_id="doc_coi",
            referenced_entity_name="Apex Electrical LLC",
            referenced_entity_role=EntityRole.NAMED_INSURED,
            referenced_document_id="doc_end",
            evidence_chain=(self.ref_coi, self.ref_end),
        )
        self.assertTrue(ent_record.is_confirmed_match)

        is_satisfied, disc = check_contractual_role_satisfaction(
            entity_record=ent_record,
            required_entity_name="Apex Electrical LLC",
            required_role=EntityRole.ADDITIONAL_INSURED,
            contract_requirement_id="REQ_AI_02",
            coverage_type=CoverageType.GENERAL_LIABILITY,
            is_requirement_validated=True,
        )
        self.assertFalse(is_satisfied)
        self.assertIsNotNone(disc)
        self.assertEqual(disc.category, DiscrepancyCategory.MISSING_EVIDENCE)
        self.assertEqual(disc.reason_code, "INSUFFICIENT_ROLE_EVIDENCE")
        self.assertTrue(disc.requires_human_review)

    def test_c17_primary_role_mismatch_referenced_role_satisfies_requirement(self):
        """C-17: Primary role mismatch (COI is NAMED_INSURED) but referenced role satisfies requirement -> satisfied, no violation."""
        ent_record = EntityReconciliationRecord(
            primary_entity_name="Apex Electrical LLC",
            primary_entity_role=EntityRole.NAMED_INSURED,
            primary_document_id="doc_coi",
            referenced_entity_name="Apex Electrical LLC",
            referenced_entity_role=EntityRole.ADDITIONAL_INSURED,
            referenced_document_id="doc_end",
            classification=EntityMatchClassification.EXACT,
            evidence_chain=(self.ref_coi, self.ref_end),
            is_confirmed_match=True,
            requires_human_review=False,
        )
        is_satisfied, disc = check_contractual_role_satisfaction(
            entity_record=ent_record,
            required_entity_name="Apex Electrical LLC",
            required_role=EntityRole.ADDITIONAL_INSURED,
            contract_requirement_id="REQ_AI_03",
            is_requirement_validated=True,
        )
        self.assertTrue(is_satisfied)
        self.assertIsNone(disc)

    def test_c18_entity_does_not_match_contractual_requirement_no_role_only_violation(self):
        """C-18: Entity does not match contractual requirement -> no role-only violation without sufficient identity evidence."""
        ent_record = EntityReconciliationRecord(
            primary_entity_name="Apex Electrical LLC",
            primary_entity_role=EntityRole.NAMED_INSURED,
            primary_document_id="doc_coi",
            referenced_entity_name="Apex Electrical LLC",
            referenced_entity_role=EntityRole.NAMED_INSURED,
            referenced_document_id="doc_end",
            classification=EntityMatchClassification.EXACT,
            evidence_chain=(self.ref_coi, self.ref_end),
            is_confirmed_match=True,
            requires_human_review=False,
        )
        is_satisfied, disc = check_contractual_role_satisfaction(
            entity_record=ent_record,
            required_entity_name="Acme Builders Inc",
            required_role=EntityRole.NAMED_INSURED,
            contract_requirement_id="REQ_NI_01",
            is_requirement_validated=True,
        )
        self.assertFalse(is_satisfied)
        self.assertIsNotNone(disc)
        self.assertNotEqual(disc.reason_code, "CONTRACTUAL_ROLE_MISMATCH")
        self.assertEqual(disc.category, DiscrepancyCategory.DOCUMENT_DISCREPANCY)
        self.assertEqual(disc.reason_code, "ENTITY_NAME_MISMATCH")

    def test_c19_requirement_id_exists_but_not_validated_creates_no_violation(self):
        """C-19: Requirement ID exists but requirement is not validated -> no confirmed violation."""
        ent_record = EntityReconciliationRecord(
            primary_entity_name="Apex Electrical LLC",
            primary_entity_role=EntityRole.NAMED_INSURED,
            primary_document_id="doc_coi",
            referenced_entity_name="Apex Electrical LLC",
            referenced_entity_role=EntityRole.NAMED_INSURED,
            referenced_document_id="doc_end",
            classification=EntityMatchClassification.EXACT,
            evidence_chain=(self.ref_coi, self.ref_end),
            is_confirmed_match=True,
            requires_human_review=False,
        )
        is_satisfied, disc = check_contractual_role_satisfaction(
            entity_record=ent_record,
            required_entity_name="Apex Electrical LLC",
            required_role=EntityRole.ADDITIONAL_INSURED,
            contract_requirement_id="REQ_UNVALIDATED",
            is_requirement_validated=False,
        )
        self.assertFalse(is_satisfied)
        self.assertIsNone(disc)

    # =========================================================================
    # Correction 2: Relationship-Specific Evidence (C-20 to C-27)
    # =========================================================================

    def test_c20_same_policy_with_only_policy_number_unconfirmed(self):
        """C-20: SAME_POLICY with matching identifiers but no relationship-specific evidence -> unconfirmed."""
        ref_coi_pol = EvidenceReference(
            document_id="doc_coi",
            document_type=DocumentType.COI,
            page_number=1,
            source_text="GL-12345",
        )
        ref_dec_pol = EvidenceReference(
            document_id="doc_dec",
            document_type=DocumentType.POLICY_DEC_PAGE,
            page_number=1,
            source_text="GL-12345",
        )
        edge = classify_document_relationship(
            edge_id="e_same_pol_bare",
            source_document_id="doc_coi",
            target_document_id="doc_dec",
            relationship_type=DocumentRelationshipType.SAME_POLICY,
            classification=EdgeClassification.CONFIRMED_EXACT,
            evidence_references=(ref_coi_pol, ref_dec_pol),
        )
        self.assertFalse(edge.is_confirmed)
        self.assertTrue(edge.requires_human_review)
        self.assertEqual(edge.classification, EdgeClassification.AMBIGUOUS)

    def test_c21_endorsement_to_policy_with_only_matching_policy_number_unconfirmed(self):
        """C-21: ENDORSEMENT_TO_POLICY with only matching policy identifiers -> unconfirmed."""
        ref_coi_pol = EvidenceReference(
            document_id="doc_coi",
            document_type=DocumentType.COI,
            page_number=1,
            source_text="GL-12345",
        )
        ref_end_pol = EvidenceReference(
            document_id="doc_end",
            document_type=DocumentType.ENDORSEMENT,
            page_number=1,
            source_text="GL-12345",
        )
        edge = classify_document_relationship(
            edge_id="e_end_pol_bare",
            source_document_id="doc_end",
            target_document_id="doc_coi",
            relationship_type=DocumentRelationshipType.ENDORSEMENT_TO_POLICY,
            classification=EdgeClassification.CONFIRMED_EXACT,
            evidence_references=(ref_end_pol, ref_coi_pol),
        )
        self.assertFalse(edge.is_confirmed)
        self.assertTrue(edge.requires_human_review)
        self.assertEqual(edge.classification, EdgeClassification.AMBIGUOUS)

    def test_c22_declaration_for_policy_without_declaration_evidence_unconfirmed(self):
        """C-22: DECLARATION_FOR_POLICY without evidence supporting declaration relationship -> unconfirmed."""
        ref_coi_generic = EvidenceReference(
            document_id="doc_coi",
            document_type=DocumentType.COI,
            page_number=1,
            source_text="GL-12345 Commercial",
        )
        ref_dec_generic = EvidenceReference(
            document_id="doc_dec",
            document_type=DocumentType.POLICY_DEC_PAGE,
            page_number=1,
            source_text="GL-12345 Commercial",
        )
        edge = classify_document_relationship(
            edge_id="e_dec_generic",
            source_document_id="doc_dec",
            target_document_id="doc_coi",
            relationship_type=DocumentRelationshipType.DECLARATION_FOR_POLICY,
            classification=EdgeClassification.CONFIRMED_EXACT,
            evidence_references=(ref_dec_generic, ref_coi_generic),
        )
        self.assertFalse(edge.is_confirmed)
        self.assertTrue(edge.requires_human_review)
        self.assertEqual(edge.classification, EdgeClassification.AMBIGUOUS)

    def test_c23_replaces_document_with_generic_citations_unconfirmed(self):
        """C-23: REPLACES_DOCUMENT with generic citations but no supersession evidence -> unconfirmed."""
        edge = classify_document_relationship(
            edge_id="e_rep_generic",
            source_document_id="doc_end",
            target_document_id="doc_coi",
            relationship_type=DocumentRelationshipType.REPLACES_DOCUMENT,
            classification=EdgeClassification.CONFIRMED_EXACT,
            evidence_references=(self.ref_end, self.ref_coi),
        )
        self.assertFalse(edge.is_confirmed)
        self.assertTrue(edge.requires_human_review)
        self.assertEqual(edge.classification, EdgeClassification.AMBIGUOUS)

    def test_c24_amends_document_with_generic_citations_unconfirmed(self):
        """C-24: AMENDS_DOCUMENT with generic citations but no amendment evidence -> unconfirmed."""
        edge = classify_document_relationship(
            edge_id="e_amend_generic",
            source_document_id="doc_end",
            target_document_id="doc_coi",
            relationship_type=DocumentRelationshipType.AMENDS_DOCUMENT,
            classification=EdgeClassification.CONFIRMED_EXACT,
            evidence_references=(self.ref_end, self.ref_coi),
        )
        self.assertFalse(edge.is_confirmed)
        self.assertTrue(edge.requires_human_review)
        self.assertEqual(edge.classification, EdgeClassification.AMBIGUOUS)

    def test_c25_duplicate_of_with_generic_citations_unconfirmed(self):
        """C-25: DUPLICATE_OF with generic citations but no duplicate evidence -> unconfirmed."""
        edge = classify_document_relationship(
            edge_id="e_dup_generic",
            source_document_id="doc_coi",
            target_document_id="doc_end",
            relationship_type=DocumentRelationshipType.DUPLICATE_OF,
            classification=EdgeClassification.CONFIRMED_EXACT,
            evidence_references=(self.ref_coi, self.ref_end),
        )
        self.assertFalse(edge.is_confirmed)
        self.assertTrue(edge.requires_human_review)
        self.assertEqual(edge.classification, EdgeClassification.AMBIGUOUS)

    def test_c26_caller_cannot_bypass_evidence_validation_with_boolean_flag(self):
        """C-26: Caller cannot bypass evidence validation by setting boolean flag to True."""
        edge = classify_document_relationship(
            edge_id="e_bypass",
            source_document_id="doc_end",
            target_document_id="doc_coi",
            relationship_type=DocumentRelationshipType.REPLACES_DOCUMENT,
            classification=EdgeClassification.CONFIRMED_EXACT,
            has_relationship_evidence=True,
            evidence_references=(self.ref_end, self.ref_coi),
        )
        self.assertFalse(edge.is_confirmed)
        self.assertTrue(edge.requires_human_review)
        self.assertEqual(edge.classification, EdgeClassification.AMBIGUOUS)

        with self.assertRaises(ValueError) as ctx:
            DocumentRelationshipEdge(
                edge_id="e_direct_bypass",
                source_document_id="doc_end",
                target_document_id="doc_coi",
                relationship_type=DocumentRelationshipType.REPLACES_DOCUMENT,
                classification=EdgeClassification.CONFIRMED_EXACT,
                is_confirmed=True,
                evidence_references=(self.ref_end, self.ref_coi),
            )
        self.assertIn("requires affirmative evidence containing replacement or supersession text", str(ctx.exception))

    def test_c27_evidence_from_wrong_source_or_target_document_rejected(self):
        """C-27: Evidence from wrong source or target document is rejected in referential integrity validation."""
        ref_third = EvidenceReference(
            document_id="doc_dec",
            document_type=DocumentType.POLICY_DEC_PAGE,
            page_number=1,
            source_text="This endorsement replaces prior form CG 20 10",
        )
        ref_coi_sup = EvidenceReference(
            document_id="doc_coi",
            document_type=DocumentType.COI,
            page_number=1,
            source_text="This endorsement replaces prior form CG 20 10",
        )
        edge = DocumentRelationshipEdge(
            edge_id="e_wrong_doc",
            source_document_id="doc_coi",
            target_document_id="doc_end",
            relationship_type=DocumentRelationshipType.REPLACES_DOCUMENT,
            classification=EdgeClassification.AMBIGUOUS,
            is_confirmed=False,
            requires_human_review=True,
            evidence_references=(ref_coi_sup, ref_third),
        )
        with self.assertRaises(ValueError) as ctx:
            CrossDocumentReconciliationResult(
                document_packet_id="pkt_c27",
                packet_manifest=(self.doc_coi_manifest, self.doc_end_manifest, self.doc_dec_manifest),
                graph_edges=(edge,),
            )
        self.assertIn("not among its associated documents", str(ctx.exception))

    # =========================================================================
    # Correction 3: Conservative Policy Family Classification (C-28 to C-31)
    # =========================================================================

    def test_c28_leading_zero_difference_without_family_evidence_conflicting(self):
        """C-28: Leading-zero difference without supporting family evidence is CONFLICTING (not POSSIBLE_FAMILY)."""
        rec = reconcile_policy_identifiers(
            coi_document_id="doc_coi",
            coi_policy_number="0012345",
            coi_evidence=self.ref_coi,
            endorsement_document_id="doc_end",
            endorsement_policy_number="12345",
            endorsement_evidence=self.ref_end,
        )
        self.assertEqual(rec.classification, PolicyMatchClassification.CONFLICTING)
        self.assertNotEqual(rec.classification, PolicyMatchClassification.POSSIBLE_FAMILY)
        self.assertFalse(rec.is_confirmed_match)
        self.assertTrue(rec.requires_human_review)

    def test_c29_arbitrary_shared_prefix_not_possible_family(self):
        """C-29: Arbitrary shared prefix with different remaining characters is CONFLICTING (not POSSIBLE_FAMILY)."""
        rec = reconcile_policy_identifiers(
            coi_document_id="doc_coi",
            coi_policy_number="COMM-1234",
            coi_evidence=self.ref_coi,
            endorsement_document_id="doc_end",
            endorsement_policy_number="COMM-9876",
            endorsement_evidence=self.ref_end,
        )
        self.assertEqual(rec.classification, PolicyMatchClassification.CONFLICTING)
        self.assertNotEqual(rec.classification, PolicyMatchClassification.POSSIBLE_FAMILY)
        self.assertFalse(rec.is_confirmed_match)
        self.assertTrue(rec.requires_human_review)

    def test_c30_documented_renewal_suffix_pattern_possible_family_never_confirmed(self):
        """C-30: Documented renewal suffix patterns classify as POSSIBLE_FAMILY and are never confirmed."""
        pairs = [
            ("GL-98765-01", "GL-98765-02"),
            ("PKG-1000/2024", "PKG-1000/2025"),
            ("POL-555-R1", "POL-555-R2"),
            ("GL-98765", "GL-98765-01"),
        ]
        for pol_a, pol_b in pairs:
            rec = reconcile_policy_identifiers(
                coi_document_id="doc_coi",
                coi_policy_number=pol_a,
                coi_evidence=self.ref_coi,
                endorsement_document_id="doc_end",
                endorsement_policy_number=pol_b,
                endorsement_evidence=self.ref_end,
            )
            self.assertEqual(rec.classification, PolicyMatchClassification.POSSIBLE_FAMILY, f"Failed for {pol_a} vs {pol_b}")
            self.assertFalse(rec.is_confirmed_match)
            self.assertTrue(rec.requires_human_review)

    def test_c31_meaningful_alphanumeric_suffix_difference_not_possible_family(self):
        """C-31: Meaningful alphanumeric suffix difference without renewal evidence is CONFLICTING."""
        rec = reconcile_policy_identifiers(
            coi_document_id="doc_coi",
            coi_policy_number="POL-12345-A",
            coi_evidence=self.ref_coi,
            endorsement_document_id="doc_end",
            endorsement_policy_number="POL-12345-B",
            endorsement_evidence=self.ref_end,
        )
        self.assertEqual(rec.classification, PolicyMatchClassification.CONFLICTING)
        self.assertNotEqual(rec.classification, PolicyMatchClassification.POSSIBLE_FAMILY)

    # =========================================================================
    # Correction 4: Contractual Duration Validation (C-32 to C-35)
    # =========================================================================

    def test_c32_earlier_endorsement_expiration_no_validated_duration_requirement_no_violation(self):
        """C-32: Earlier endorsement expiration with no validated duration requirement -> no confirmed violation."""
        rec = reconcile_dates(
            policy_document_id="doc_coi",
            policy_effective_date=date(2025, 1, 1),
            policy_expiration_date=date(2025, 12, 31),
            policy_date_evidence=(self.ref_coi,),
            endorsement_document_id="doc_end",
            endorsement_effective_date=date(2025, 1, 1),
            endorsement_expiration_date=date(2025, 6, 30),
            endorsement_date_evidence=(self.ref_end,),
            evaluation_date=date(2025, 3, 1),
            contractual_duration_requirement_id=None,
        )
        self.assertTrue(rec.is_policy_active_on_evaluation_date)
        self.assertTrue(rec.is_endorsement_active_on_evaluation_date)
        self.assertTrue(rec.is_premature_expiration)
        self.assertFalse(rec.requires_human_review)
        self.assertIsNone(rec.discrepancy_category)

    def test_c33_earlier_endorsement_expiration_requirement_does_not_demand_policy_expiration_no_violation(self):
        """C-33: Earlier endorsement expiration with requirement that does not require coverage through policy expiration -> no confirmed violation."""
        rec = reconcile_dates(
            policy_document_id="doc_coi",
            policy_effective_date=date(2025, 1, 1),
            policy_expiration_date=date(2025, 12, 31),
            policy_date_evidence=(self.ref_coi,),
            endorsement_document_id="doc_end",
            endorsement_effective_date=date(2025, 1, 1),
            endorsement_expiration_date=date(2025, 6, 30),
            endorsement_date_evidence=(self.ref_end,),
            evaluation_date=date(2025, 3, 1),
            contractual_duration_requirement_id="REQ_DUR_01",
            required_coverage_end_date=date(2025, 5, 1),
            requires_coverage_through_policy_expiration=False,
            is_duration_requirement_validated=True,
        )
        self.assertTrue(rec.is_endorsement_active_on_evaluation_date)
        self.assertFalse(rec.requires_human_review)
        self.assertIsNone(rec.discrepancy_category)

    def test_c34_explicit_validated_requirement_through_policy_expiration_confirmed_violation(self):
        """C-34: Explicit validated requirement requiring coverage through policy expiration, with earlier endorsement expiration -> confirmed violation."""
        rec = reconcile_dates(
            policy_document_id="doc_coi",
            policy_effective_date=date(2025, 1, 1),
            policy_expiration_date=date(2025, 12, 31),
            policy_date_evidence=(self.ref_coi,),
            endorsement_document_id="doc_end",
            endorsement_effective_date=date(2025, 1, 1),
            endorsement_expiration_date=date(2025, 6, 30),
            endorsement_date_evidence=(self.ref_end,),
            evaluation_date=date(2025, 3, 1),
            contractual_duration_requirement_id="REQ_DUR_POLICY_SPAN",
            requires_coverage_through_policy_expiration=True,
            is_duration_requirement_validated=True,
        )
        self.assertTrue(rec.requires_human_review)
        self.assertEqual(rec.discrepancy_category, DiscrepancyCategory.CONFIRMED_CONTRACTUAL_VIOLATION)
        self.assertEqual(rec.review_reason_code, "PREMATURE_EXPIRATION_VIOLATION")

    def test_c35_requirement_id_exists_but_actual_duration_terms_missing_unresolved(self):
        """C-35: Requirement ID exists but actual duration terms missing -> unresolved."""
        rec = reconcile_dates(
            policy_document_id="doc_coi",
            policy_effective_date=date(2025, 1, 1),
            policy_expiration_date=date(2025, 12, 31),
            policy_date_evidence=(self.ref_coi,),
            endorsement_document_id="doc_end",
            endorsement_effective_date=date(2025, 1, 1),
            endorsement_expiration_date=date(2025, 6, 30),
            endorsement_date_evidence=(self.ref_end,),
            evaluation_date=date(2025, 3, 1),
            contractual_duration_requirement_id="REQ_DUR_UNVALIDATED",
            is_duration_requirement_validated=False,
        )
        self.assertTrue(rec.requires_human_review)
        self.assertEqual(rec.discrepancy_category, DiscrepancyCategory.DOCUMENT_DISCREPANCY)
        self.assertEqual(rec.review_reason_code, "UNVALIDATED_DURATION_REQUIREMENT")

    # =========================================================================
    # Correction 5: Empty vs Incomplete Relationship Graphs (C-36 to C-38)
    # =========================================================================

    def test_c36_valid_empty_graph_explicitly_represented_as_evaluated_empty(self):
        """C-36: Valid empty graph explicitly represented as EVALUATED_EMPTY."""
        result = CrossDocumentReconciliationResult(
            document_packet_id="packet_empty",
            packet_manifest=(self.doc_coi_manifest, self.doc_end_manifest),
            graph_edges=(),
        )
        self.assertEqual(result.graph_evaluation_status, GraphEvaluationStatus.EVALUATED_EMPTY)
        self.assertFalse(result.all_relationships_confirmed)

    def test_c37_incomplete_or_unevaluated_graph_distinguishable_from_evaluated_empty(self):
        """C-37: Incomplete/unprocessed graph distinguishable from valid empty graph (UNEVALUATED / INCOMPLETE)."""
        result_uneval = CrossDocumentReconciliationResult(
            document_packet_id="packet_uneval",
            packet_manifest=(self.doc_coi_manifest, self.doc_end_manifest),
            graph_edges=(),
            graph_evaluation_status=GraphEvaluationStatus.UNEVALUATED,
        )
        self.assertEqual(result_uneval.graph_evaluation_status, GraphEvaluationStatus.UNEVALUATED)
        self.assertNotEqual(result_uneval.graph_evaluation_status, GraphEvaluationStatus.EVALUATED_EMPTY)

        result_incomp = CrossDocumentReconciliationResult(
            document_packet_id="packet_incomp",
            packet_manifest=(self.doc_coi_manifest, self.doc_end_manifest),
            graph_edges=(),
            graph_evaluation_status=GraphEvaluationStatus.INCOMPLETE,
        )
        self.assertEqual(result_incomp.graph_evaluation_status, GraphEvaluationStatus.INCOMPLETE)
        self.assertNotEqual(result_incomp.graph_evaluation_status, GraphEvaluationStatus.EVALUATED_EMPTY)

    def test_c38_neither_empty_nor_unevaluated_state_confirms_compliance(self):
        """C-38: Neither empty nor unevaluated state independently establishes compliance (all_relationships_confirmed = False)."""
        res_empty = CrossDocumentReconciliationResult(
            document_packet_id="packet_empty_2",
            packet_manifest=(self.doc_coi_manifest, self.doc_end_manifest),
            graph_edges=(),
            graph_evaluation_status=GraphEvaluationStatus.EVALUATED_EMPTY,
        )
        self.assertFalse(res_empty.all_relationships_confirmed)

        res_uneval = CrossDocumentReconciliationResult(
            document_packet_id="packet_uneval_2",
            packet_manifest=(self.doc_coi_manifest, self.doc_end_manifest),
            graph_edges=(),
            graph_evaluation_status=GraphEvaluationStatus.UNEVALUATED,
        )
        self.assertFalse(res_uneval.all_relationships_confirmed)

        res_incomp = CrossDocumentReconciliationResult(
            document_packet_id="packet_incomp_2",
            packet_manifest=(self.doc_coi_manifest, self.doc_end_manifest),
            graph_edges=(),
            graph_evaluation_status=GraphEvaluationStatus.INCOMPLETE,
        )
        self.assertFalse(res_incomp.all_relationships_confirmed)


if __name__ == "__main__":
    unittest.main()
